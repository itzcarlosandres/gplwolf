<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}
$rss_direction = '';
if( 'RSS' === $selectFeed && 'column' === $rss_s3_direction ){
	$rss_direction = $rss_s3_direction;
}
?>
<div class="tp-sf-feed d-flex flex-row style-3-<?php echo $rss_direction; ?>">
	<?php
		$imghideclass = '';
	if ( empty( $ImageURL ) ) {
		$imghideclass = 'tp-soc-image-not-found';
	}

		echo '<div class="tp-sf-contant ' . esc_attr( $imghideclass ) . '">';
				require THEPLUS_WSTYLES . 'social-feed/social-feed-ob-style.php';
	if ( ! empty( $Massage ) ) {
		echo $Massage_html;
	}
	if ( ! empty( $Description ) ) {
		include THEPLUS_WSTYLES . 'social-feed/feed-Description.php';
	}
				echo $Header_html;
				require THEPLUS_WSTYLES . 'social-feed/feed-footer.php';
		echo '</div>';

	if ( ! empty( $ImageURL ) ) {
		?>

		<div class="tp-sf-contant-img" style="background-image: url('<?php echo esc_url( $ImageURL ); ?>');">
			<?php
				if ( 'RSS' === $selectFeed ) {
					if ( 'yes' === $rssfeed_icon ) {
						echo $Iconlogo;
					}
				} else {
					echo $Iconlogo;
				}
				include THEPLUS_WSTYLES . 'social-feed/fancybox-feed.php';
			?>
		</div>
		<?php
	}
	?>

</div>
<?php
	echo $Copyid_html;
