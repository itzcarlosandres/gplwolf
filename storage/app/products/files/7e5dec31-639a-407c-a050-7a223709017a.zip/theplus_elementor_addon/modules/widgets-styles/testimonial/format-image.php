<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

$tp_border_reduis = !empty( $settings['featured_image_radius']) ? $settings['featured_image_radius'] : '';

$has_border_radius = ! empty( $tp_border_reduis['top'] ) || ! empty( $tp_border_reduis['right'] ) || ! empty( $tp_border_reduis['bottom'] ) || ! empty( $tp_border_reduis['left'] );

if ( $tlContentFrom == 'tlrepeater' ) {
	$featured_image_url = $testiImage;
	$feat_id            = $testiImageId;
} else {
	global $post;
	$featured_image_url = wp_get_attachment_url( get_post_thumbnail_id( get_the_ID() ) );
}

$tsize = '';
if ( ! empty( $featured_image_url ) ) {
	if ( $display_thumbnail == 'yes' && ! empty( $thumbnail ) ) {
		$tsize = $thumbnail;
	} else {
		$tsize = 'tp-image-grid';
	}

	if ( $tlContentFrom == 'tlrepeater' ) {
		$featured_image = tp_get_image_rander( $feat_id, $tsize );
	} else {
		$featured_image = tp_get_image_rander( get_the_ID(), $tsize, array(), 'post' );
	}
} else {
	$featured_image = theplus_get_thumb_url();
	if ( $tlContentFrom == 'tlrepeater' ) {
		$featured_image = $featured_image = '<img src="' . esc_url( $featured_image ) . '" alt="' . esc_attr( $testiLabel ) . '">';
	} else {
		$featured_image = $featured_image = '<img src="' . esc_url( $featured_image ) . '" alt="' . esc_attr( get_the_title() ) . '">';
	}
}

?>
<div class="testimonial-featured-image">
	<?php
	if ( ! empty( $has_border_radius ) ) {
		?>
		<span class="thumb-wrap">
			<?php echo $featured_image; ?>
		</span>
		<?php
	} else {
		?>
		<span class="thumb-wrap" style="
			display: inline-block;
			-webkit-mask-image: url('<?php echo esc_url( L_THEPLUS_ASSETS_URL . 'svg/testimonial-mask.svg' ); ?>');
			-webkit-mask-repeat: no-repeat;
			mask-image: url('<?php echo esc_url( L_THEPLUS_ASSETS_URL . 'svg/testimonial-mask.svg' ); ?>');
			mask-size: contain;
			width: 75px;
            height: 90px;
		">
			<?php echo $featured_image; ?>
		</span>
		<?php
	}
	?>
</div>