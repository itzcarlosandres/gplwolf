<?php

use Elementor\Base_Data_Control;

if ( ! defined( 'ABSPATH' ) ) exit;


class Theplus_Woo_Setting extends Base_Data_Control {

  
	public function get_type() {
		return 'tpae_woo_setting';
	}

	public function content_template() {

		$woo_plugin_status = apply_filters( 'tpae_get_plugin_status','woocommerce/woocommerce.php' );

		?>
		<#
			var tp_notice = data.controlValue || data.notice || '';
			var tp_btn_txt = data.controlValue || data.button_text || 'Open Advanced Settings';
		#>

		<div style=" background-color:var(--e-a-bg-active);border-top:3px solid #6660EF;padding:10px 20px 15px 20px;font-style:italic;">
			<p style="margin:0; color:var(--e-a-bg-invert);font-size:12px;line-height:15px;font-weight:300;letter-spacing:0.3px;">
				<b style="color:var(--e-a-bg-logo)!important;font-size:13px;line-height:30px;">Note :</b><br>
				{{{ tp_notice }}}
			</p>
		</div>

		<?php if ( 'active' === $woo_plugin_status ) { ?>
			<a href="<?php echo esc_url( admin_url( 'admin.php?page=wc-settings&tab=advanced' ) ); ?>" target=_blank style="position:relative;display:flex;justify-content:center;min-height:39.4px;color:#fff;font-weight:500;background-color:#6660EF;border-radius:3px;padding:12px 24px;margin-top:15px;border-block-end:none;">
				{{{tp_btn_txt}}}
		    </a>
		<?php } else {  ?>
				<button class="elementor-button elementor-button-default tp-install-woo" data-tp_btn_txt="{{{tp_btn_txt}}}" data-tp_redirect_link="admin.php?page=wc-settings&tab=advanced" data-tp_install="true" style="position:relative;display:flex;justify-content:center;min-height:39.4px;color:#fff;font-weight:600;background-color:#6660EF;border-radius:3px;padding:12px 24px;margin-top:15px;border-block-end:none;">
					Install WooCommerce
					<!-- <span class="tp-nextbtn-loader" style="display: none; position: absolute; left: 75px; top: 50%; width: 16px; height: 16px; margin-top: -8px;border: 2px solid #fff; border-top-color: transparent; border-radius: 50%; animation: tp-spin 1s linear infinite;"></span> -->
				</button>
			<?php } ?>
			<style>@keyframes tp-spin {from { transform: rotate(0deg); }to { transform: rotate(360deg); }}</style>
		<?php
	}
}
