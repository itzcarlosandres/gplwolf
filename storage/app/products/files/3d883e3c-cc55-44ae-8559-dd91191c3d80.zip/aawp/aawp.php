<?php
/**
 * Plugin Name:       AAWP
 * Plugin URI:        https://getaawp.com
 * Description:       The best WordPress plugin for Amazon Affiliates.
 * Version:           4.4.0
 * Requires at least: 5.6
 * Requires PHP:      7.2
 * Author:            AAWP
 * Author URI:        https://getaawp.com
 * Text Domain:       aawp
 * Domain Path:       /languages
 *
 * @package         AAWP
 * @author          AAWP
 * @copyright       Copyright (c) AAWP
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

if ( ! function_exists( 'aawp_fs' ) ) {
    // Create a helper function for easy SDK access.
    function aawp_fs() {
        global $aawp_fs;

        if ( ! isset( $aawp_fs ) ) {
            // Include Freemius SDK.
            require_once dirname(__FILE__) . '/vendor/freemius/wordpress-sdk/start.php';

            $aawp_fs = fs_dynamic_init( array(
                'id'                  => '14610',
                'slug'                => 'aawp',
                'premium_slug'        => 'aawp',
                'type'                => 'plugin',
                'public_key'          => 'pk_ce114e70760029b4f342e85b66478',
                'is_premium'          => true,
                'is_premium_only'     => true,
                'has_addons'          => false,
                'has_paid_plans'      => true,
                'is_org_compliant'    => false,
                'has_affiliation'     => 'all',
                'menu'                => array(
                    'slug'           => 'aawp',
                    'first-path'     => 'admin.php?page=aawp',
                    'support'        => false,
                    'contact'        => false
                ),
            ) );
        }

        return $aawp_fs;
    }

    // Init Freemius.
    aawp_fs();
    // Signal that SDK was initiated.
    do_action( 'aawp_fs_loaded' );
}

// Plugin Root File.
define( 'AAWP_PLUGIN_FILE', __FILE__ );

// Plugin Folder Path.
define( 'AAWP_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );

// Plugin Directory URL.
define( 'AAWP_PLUGIN_URL', plugin_dir_url( __FILE__ ) );

// Plugin Version.
const AAWP_VERSION = '4.4.0';

// Require Autoload.
require_once __DIR__ . '/vendor/autoload.php';
require_once __DIR__ . '/vendor/woocommerce/action-scheduler/action-scheduler.php';

/**
 * Return the main instance of the Plugin.
 *
 * @since  1.2.0
 *
 * @return Plugin.
 */
function aawp() {
	return \AAWP\Plugin::instance();
}
aawp();

/**
 * The activation hook.
 *
 * @return void.
 */
function aawp_activation() {

	// Installation.
	require_once plugin_dir_path( __FILE__ ) . '/includes/install.php';

	if ( function_exists( 'aawp_run_install' ) ) {
		aawp_run_install();
	}

	set_transient( 'aawp_welcome_screen_activation_redirect', true, 30 );
}
register_activation_hook( __FILE__, 'aawp_activation' );