<?php
/**
 * Admin Hooks
 *
 * @since       3.4.0
 */

// Exit if accessed directly
if( !defined( 'ABSPATH' ) ) exit;

/**
 * Temporarily redirect dashboard page
 */
function aawp_admin_temporarily_redirect_dashboard_page() {

    if ( isset( $_GET['page'] ) && $_GET['page'] == 'aawp-dashboard' && defined( 'AAWP_ADMIN_SETTINGS_URL' ) ) {
        wp_redirect( AAWP_ADMIN_SETTINGS_URL );
        exit;
    }
}
add_action( 'admin_init', 'aawp_admin_temporarily_redirect_dashboard_page' );

function aawp_admin_remove_first_submenu_page() {
    remove_submenu_page( 'index.php', 'my-welcome' );
}
add_action( 'admin_head', 'aawp_admin_remove_first_submenu_page' );