<?php
/**
 * Geotargeting
 *
 * @package     AAWP\Functions\Components
 * @since       3.2.0
 */

// Exit if accessed directly
if( !defined( 'ABSPATH' ) ) exit;

/*
 * Register component
 */
function aawp_settings_register_geotargeting_component( $functions ) {

    $functions[] = 'geotargeting';

    return $functions;
}
add_filter( 'aawp_settings_functions', 'aawp_settings_register_geotargeting_component' );

/*
 * Render settings
 */
function aawp_settings_geotargeting_render() {

    $options_geotargeting = aawp_get_options( 'geotargeting' );

    $geotargeting = ( isset ( $options_geotargeting['geotargeting'] ) && $options_geotargeting['geotargeting'] == '1' ) ? 1 : 0;
    $geotargeting_docs_url = ( aawp_is_lang_de() ) ? 'https://aawp.de/docs/article/geotargeting/' : 'https://getaawp.com/docs/article/geo-targeting/';

    $geotargeting_mode_options = array(
        'title' => __('Product search (Recommended)', 'aawp'),
        'asin' => __('Product page', 'aawp')
    );

    $geotargeting_mode = ( ! empty ( $options_geotargeting['geotargeting_mode'] ) ) ? $options_geotargeting['geotargeting_mode'] : 'title';

    ?>
    <!-- Geotargeting -->
    <h4><span class="aawp-icon-globe"></span> <?php _e('Geotargeting', 'aawp'); ?> (<a href="<?php echo ( aawp_is_lang_de() ) ? 'https://aawp.de/docs/article/dsgvo/' : 'https://getaawp.com/docs/article/gdpr/'; ?>" target="_blank" rel="nofollow"><?php _e('GDPR warning', 'aawp'); ?></a>)</h4>
    <p class="message info">
        <?php _e('To determine the country of origin, the current IP address of your page visitor will be analyzed through a third party service. The activation and use of the geo-targeting function is voluntary and is the responsibility of the site administrator.', 'aawp' ); ?>
    </p>
    <p>
        <input type="checkbox" id="aawp_geotargeting" name="aawp_geotargeting[geotargeting]" value="1" <?php echo( $geotargeting == 1 ? 'checked' : '' ); ?>>
        <label for="aawp_geotargeting"><?php _e('Enable Geotargeting', 'aawp'); ?></label>
    </p>
    <p>
        <?php _e( 'Link target', 'aawp' ); ?>
        <select id="aawp_geotargeting_mode" name="aawp_geotargeting[geotargeting_mode]">
            <?php foreach ( $geotargeting_mode_options as $key => $label ) { ?>
                <option value="<?php echo $key; ?>" <?php selected( $geotargeting_mode, $key ); ?>><?php echo esc_html( $label ); ?></option>
            <?php } ?>
        </select>
    </p>
    <p class="description">
        <?php printf( wp_kses( __( 'Please take a look into the <a href="%s" target="_blank">documentation</a> for more information about the geotargeting feature.', 'aawp' ), array(  'a' => array( 'href' => array(), 'target' => '_blank' ) ) ), esc_url( $geotargeting_docs_url ) ); ?>
    </p>
    <?php
}

function aawp_geotargeting_maybe_extend_product_container_attributes( $attributes ) {

    $options_geotargeting = aawp_get_options( 'geotargeting' );
    $affiliate_links   = aawp_get_option( 'affiliate_links', 'general' );

    $geotargeting = isset( $options_geotargeting['geotargeting'] ) &&  $options_geotargeting['geotargeting'] === '1' && 'shortened' !== $affiliate_links ? 1 : 0;

    if ( $geotargeting )
        $attributes['geotargeting'] = 'true';

    return $attributes;
}
add_filter( 'aawp_product_container_attributes', 'aawp_geotargeting_maybe_extend_product_container_attributes' );

// Deprecated
function aawp_geotargeting_maybe_update_field_container( $result, $request, $container_attributes ) {
    if ( empty ( $result ) )
        return $result;

    $options_geotargeting = aawp_get_options( 'geotargeting' );

    $geotargeting = ( isset ( $options_geotargeting['geotargeting'] ) && $options_geotargeting['geotargeting'] == '1' ) ? 1 : 0;

    if ( $geotargeting && strpos( $result, 'data-aawp-product-title' ) == false) {

        if ( ! in_array( $request, array( 'button_detail' ) ) ) { // 'link', 'thumb', 'star_rating', 'prime', 'premium', 'button', linked values etc.
            //$result = str_replace('<a', '<a ' . $container_attributes, $result );
        }
    }

    return $result;
}
//add_filter( 'aawp_fields_result', 'aawp_geotargeting_maybe_update_field_container', 20, 3 );


/**
 * Enqueue geotargeting script data
 *
 * 1.) Prepare tracking ids
 * 2.) Setup localized stores
 */
function aawp_embed_geotargeting_script_data() {

    if ( aawp_is_user_admin() )
        return;

    $options_api = aawp_get_options( 'api' );
    $stores = aawp_get_amazon_stores();

    if ( empty( $options_api['country'] ) )
        return;

    $default_store = $options_api['country'];
    //$default_store = 'ca';

    $options_geotargeting = aawp_get_options( 'geotargeting' );
    $affiliate_links   = aawp_get_option( 'affiliate_links', 'general' );

    $geotargeting = isset( $options_geotargeting['geotargeting'] ) &&  $options_geotargeting['geotargeting'] === '1' && 'shortened' !== $affiliate_links ? 1 : 0;

    if ( ! apply_filters( 'aawp_settings_geotargeting', $geotargeting ) ) {
        return;
    }

    $geotargeting_mode = ( ! empty ( $options_geotargeting['geotargeting_mode'] ) ) ? $options_geotargeting['geotargeting_mode'] : 'title';

    // Settings
    $settings = array( 'store' => $default_store, 'mode' => $geotargeting_mode );

    //aawp_debug_log( __FUNCTION__ . ' >> $settings:' );
    //aawp_debug_log( $settings );

    // Collect tracking IDs
    $tracking_ids = array();

    foreach ( $stores as $key => $label ) {

        if ( ! empty ( $options_geotargeting['associate_tag_' . $key] ) && $key != $default_store )
            $tracking_ids[$key] = $options_geotargeting['associate_tag_' . $key];
    }

    if ( sizeof( $tracking_ids ) == 0 )
        return;

    //aawp_debug_log( __FUNCTION__ . ' >> $tracking_ids:' );
    //aawp_debug_log( $tracking_ids );

    // Build localized stores
    $localized_stores = array();

    // https://www.proxynova.com/proxy-server-list/
    // https://ipinfo.io/__IP__/json/
    // http://ontheworldmap.com/world-map-2500.jpg

	if ( ! empty( $tracking_ids['com.au'] ) && 'com.au' !== $default_store ) {
		$localized_stores['au'] = 'com.au'; // Australia
        $localized_stores['nz'] = 'com.au'; // New Zealand
	}

    if ( ! empty( $tracking_ids['ae'] ) && 'ae' !== $default_store ) {
        $localized_stores['ae'] = 'ae'; // UAE
    }

    if ( ! empty( $tracking_ids['com.be'] ) && 'com.be' !== $default_store ) {
        $localized_stores['be'] = 'com.be'; // Belgium
    }

    if ( ! empty( $tracking_ids['com.br'] ) && 'com.br' !== $default_store ) {
        $localized_stores['br'] = 'com.br'; // Brazil
    }

    if ( ! empty( $tracking_ids['ca'] ) && 'ca' !== $default_store ) {
        $localized_stores['ca'] = 'ca'; // Canada
    }

    if ( ! empty( $tracking_ids['cn'] ) && 'cn' !== $default_store ) {
        $localized_stores['cn'] = 'cn'; // China
    }

    if ( ! empty( $tracking_ids['de'] ) && 'de' !== $default_store ) {
        $localized_stores['de'] = 'de'; // Germany
        $localized_stores['at'] = 'de'; // Austria
        $localized_stores['ch'] = 'de'; // Switzerland
        $localized_stores['lu'] = 'de'; // Luxembourg
    }

    if ( ! empty( $tracking_ids['eg'] ) && 'eg' !== $default_store ) {
        $localized_stores['eg'] = 'eg'; // Egypt
    }

    if ( ! empty( $tracking_ids['es'] ) && 'es' !== $default_store ) {
        $localized_stores['es'] = 'es'; // Spain
    }

    if ( ! empty( $tracking_ids['fr'] ) && 'fr' !== $default_store ) {
        $localized_stores['fr'] = 'fr'; // France
    }

    if ( ! empty( $tracking_ids['nl'] ) && 'nl' !== $default_store ) {
        $localized_stores['nl'] = 'nl'; // Netherlands
    }

    if ( ! empty( $tracking_ids['in'] ) && 'in' !== $default_store ) {
        $localized_stores['in'] = 'in'; // India
    }

    if ( ! empty( $tracking_ids['ie'] ) && 'ie' !== $default_store ) {
        $localized_stores['ie'] = 'ie'; // Ireland
    }

    if ( ! empty( $tracking_ids['it'] ) && 'it' !== $default_store ) {
        $localized_stores['it'] = 'it'; // Italy
    }

    if ( ! empty( $tracking_ids['co.jp'] ) && 'co.jp' !== $default_store ) {
        $localized_stores['jp'] = 'co.jp'; // Japan
    }

    if ( ! empty( $tracking_ids['sa'] ) && 'sa' !== $default_store ) {
        $localized_stores['sa'] = 'sa'; // Saudi Arabia
    }

    if ( ! empty( $tracking_ids['se'] ) && 'se' !== $default_store ) {
        $localized_stores['se'] = 'se'; // Sweden
    }

    if ( ! empty( $tracking_ids['sg'] ) && 'sg' !== $default_store ) {
        $localized_stores['sg'] = 'sg'; // Singapore
    }

    if ( ! empty( $tracking_ids['pl'] ) && 'pl' !== $default_store ) {
        $localized_stores['pl'] = 'pl'; // Poland
    }

    if ( ! empty( $tracking_ids['com.tr'] ) && 'com.tr' !== $default_store ) {
        $localized_stores['tr'] = 'com.tr'; // Turkey
    }

    if ( ! empty( $tracking_ids['com.mx'] ) && 'com.mx' !== $default_store ) {
        $localized_stores['mx'] = 'com.mx'; // Mexico
    }

    if ( ! empty( $tracking_ids['co.uk'] ) && 'co.uk' !== $default_store ) {
        $localized_stores['gb'] = 'co.uk'; // UK
        $localized_stores['ie'] = 'co.uk'; // Ireland
    }

    if ( ! empty( $tracking_ids['com'] ) && 'com' !== $default_store ) {
        $localized_stores['us'] = 'com'; // USA
        $localized_stores['ar'] = 'com'; // Argentina
        $localized_stores['cl'] = 'com'; // Chile
        $localized_stores['pe'] = 'com'; // Peru
        $localized_stores['bo'] = 'com'; // Bolivia
        $localized_stores['py'] = 'com'; // Paraguay
        $localized_stores['co'] = 'com'; // Colombia
        $localized_stores['ve'] = 'com'; // Venezuela
        $localized_stores['ec'] = 'com'; // Ecuador

        // Country fallback
        if ( empty( $tracking_ids['ca'] ) && ! isset( $localized_stores['ca'] ) && 'ca' !== $default_store )
            $localized_stores['ca'] = 'com'; // Canada

        if ( empty( $tracking_ids['com.mx'] ) && ! isset( $localized_stores['mx'] ) && 'com.mx' !== $default_store )
            $localized_stores['mx'] = 'com'; // Mexico

	    if ( empty( $tracking_ids['com.au'] ) && ! isset( $localized_stores['au'] ) && 'com.au' !== $default_store )
		    $localized_stores['au'] = 'com'; // Australia
    }

    ?>
    <script type="text/javascript">
        /* <![CDATA[ */
            var aawp_geotargeting_settings = <?php echo json_encode( $settings ); ?>;
            var aawp_geotargeting_localized_stores = <?php echo json_encode( $localized_stores ); ?>;
            var aawp_geotargeting_tracking_ids = <?php echo json_encode( $tracking_ids ); ?>;
        /* ]]> */
    </script>
    <?php
}
add_action( 'wp_footer', 'aawp_embed_geotargeting_script_data', 100 );

/**
 * WP Rocket Compatibility: Prevent geotargeting inline js from being stripped
 *
 * @param $pattern
 * @return array
 */
function aawp_third_party_wprocket_exclude_inline_js( $pattern ) {

    /**
     * Source: https://github.com/wp-media/wp-rocket-helpers/tree/master/static-files/wp-rocket-static-exclude-inline-js
     */
    $pattern[] = 'var aawp_geotargeting_';

    return $pattern;
}
add_filter( 'rocket_excluded_inline_js_content', 'aawp_third_party_wprocket_exclude_inline_js' );