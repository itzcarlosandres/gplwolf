<?php
/**
 * Amazon Product Advertising API v5
 *
 * The use of this library is strictly prohibited without explicit permission.
 *
 * Copyright 2020 flowdee. All Rights Reserved.
 *
 * Twitter: https://twitter.com/flowdee
 * GitHub: https://github.com/flowdee
 */
namespace Flowdee\AmazonPAAPI5WP;

/**
 * Class BaseRequest
 *
 * @category Class
 * @package Flowdee\AmazonPAAPI5
 * @author flowdee
 */
class BaseRequest {

    /**
     * Request Path
     *
     * @var string
     */
    public $Path;

    /**
     * Request Path
     *
     * @var string
     */
    public $Target;

    /**
     * Partner type
     *
     * @var string
     */
    public $PartnerType = 'Associates';

    /**
     * Partner tag
     *
     * @var string
     */
    public $PartnerTag;

    /**
     * Resources
     *
     * @var string
     */
    public $Resources = array();

    /**
     * Condition
     *
     * @var string
     */
    public $Condition = 'Any';

    /**
     * Offer Count
     *
     * @var int
     */
    public $OfferCount = 1;

    /**
     * Merchant
     *
     * @var string
     */
    public $Merchant = 'All';

    /**
     * Language Of Preference
     *
     * @since 3.40.2
     */
    public $LanguagesOfPreference;

     /**
     * Language Of Preference
     *
     * @since 3.40.2
     */
    public $CurrencyOfPreference;

    /**
     * Get Request Path
     *
     * @return string
     */
    public function getPath() {
        return $this->Path;
    }

    /**
     * Get Request Target
     *
     * @return string
     */
    public function getTarget() {
        return $this->Target;
    }

    /**
     * Set partner tag
     *
     * @param $partnerTag
     */
    public function setPartnerTag( $partnerTag ) {
        $this->PartnerTag = $partnerTag;
    }

    /**
     * Set resources
     *
     * @param array $resources
     */
    public function setResources( $resources ) {
        $this->Resources = $resources;
    }

    /**
     * Get "condition" pairings
     *
     * @return array
     */
    private function getConditionPairings() {

        return array(
            'any' => 'Any',
            'new' => 'New',
            'used' => 'Used',
            'collectible' => 'Collectible',
            'refurbished' => 'Refurbished'
        );
    }

    /**
     * Set condition
     *
     * @param $condition
     */
    public function setCondition( $condition ) {

        if ( empty ( $condition ) )
            return;

        $pairings = $this->getConditionPairings();

        if ( isset ( $pairings[$condition] ) )
            $this->Condition = $pairings[$condition];
    }

    /**
     * Set offer count
     *
     * @param int $offerCount
     */
    public function setOfferCount( $offerCount ) {

        if ( ! empty ( $offerCount ) )
            $this->OfferCount = $offerCount;
    }

    /**
     * Set merchant
     *
     * @param int $merchant
     */
    public function setMerchant( $merchant ) {

        if ( ! empty ( $merchant ) )
            $this->Merchant = $merchant;
    }

    /**
     * Languages in order of preference in which the item information should be returned in response. 
     * By default the item information is returned in the default language of the marketplace.
     * Expected locale format is the ISO 639 language code followed by underscore followed by the ISO 3166 country code (i.e. en_US, fr_CA etc.)
     * 
     * @since 3.40.2
     *
     * @param string $language Prefered Language
     */
    public function setLanguageOfPreference( $language ) {

        if ( ! empty ( $language ) )
            $this->LanguagesOfPreference = $language;
    }

    /**
     * Currency of preference in which the prices information should be returned in response.
     * By default the prices are returned in the default currency of the marketplace.
     * Expected currency code format is the ISO 4217 currency code (i.e. USD, EUR etc.).
     *
     * @since 3.40.2
     *
     * @param string $currency Prefered Currency
     */
    public function setCurrencyOfPreference( $currency ) {

        if ( ! empty ( $currency ) )
            $this->CurrencyOfPreference = $currency;
    }
}