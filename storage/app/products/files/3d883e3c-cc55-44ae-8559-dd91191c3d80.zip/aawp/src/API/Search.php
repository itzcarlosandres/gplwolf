<?php

namespace AAWP\API;

/**
 * Search functionality.
 *
 * @since 3.30.0
 */
class Search {

	/**
	 * Search Endpoint.
	 *
	 * @since 3.30.0
	 *
	 * @var $endpoint The search API endpoint.
	 */
	private $endpoint = 'https://api.getaawp.com/v1/search/products';

	/**
	 * Get products from AAWP API by search term.
	 *
	 * @param string $term    The Search Term.
	 * @param int    $count   The number of products to display.
	 * @param string $sort_by Sort the products by.
	 *
	 * @since 3.30.0
	 */
	private function get_products( $term, $count = 10, $sort_by = '' ) { //phpcs:ignore Generic.Metrics.CyclomaticComplexity.MaxExceeded

		if ( defined( 'AAWP_API_URL' ) ) {
			$this->endpoint = AAWP_API_URL . '/search/products';
		}

		// Log the search term.
		aawp_log( 'AAWP Search API', 'Search Term: <code>' . $term . '</code>' );

		// Data to be passed to the API.
		$data = [
			'search_term' => $term,
			'store'       => \aawp_get_option( 'country', 'aawp_api' ),
			'sortby'      => $sort_by,
		];

		$aawp_api_key = aawp_get_option( 'key', 'aawp_api' );
		$license_key  = aawp_fs()->_get_license()->secret_key ?? '';

		// Options to the API Call.
		$options = [
			'body'    => wp_json_encode( $data ),
			'headers' => [
				'Content-Type'        => 'application/json',
				'Authorization'       => ! empty( $aawp_api_key ) ? $aawp_api_key : $license_key,
				'Is-AAWP-API-Key'     => ! empty( $aawp_api_key ) ? '1' : '0',
				'AAWP-Version'        => AAWP_VERSION,
				'AAWP-Referer-Domain' => wp_parse_url( site_url(), PHP_URL_HOST ),
			],
			'timeout' => 60,
		];

		// Remote API Call.
		$response = wp_remote_post( $this->endpoint, $options );

		if ( is_wp_error( $response ) ) {

			aawp_log(
				'AAWP Product API',
				'<code>' . esc_html( $response->get_error_message() ) . '</code>'
			);

			return [
				'code'    => '500',
				'message' => esc_html__( 'Error connecting to the AAWP API', 'aawp' ),
			];
		}

		$body_raw  = wp_remote_retrieve_body( $response );
		$http_code = wp_remote_retrieve_response_code( $response );
		$body_json = json_decode( $body_raw, true );

		// JSON response.
		if ( json_last_error() === JSON_ERROR_NONE ) {

			if ( $http_code != 200 && $http_code != 404 ) { //phpcs:ignore Universal.Operators.StrictComparisons.LooseNotEqual
				$code    = isset( $body_json['code'] ) ? $body_json['code'] : '0';
				$message = isset( $body_json['message'] ) ? $body_json['message'] : 'unknown';

				update_option( 'aawp_products_api_error', $code . ': ' . $message );
			}

			if ( $http_code == 200 ) { //phpcs:ignore Universal.Operators.StrictComparisons.LooseEqual
				delete_option( 'aawp_products_api_error' );
			}

			return ! empty( $body_json ) && is_array( $body_json ) ? array_slice( $body_json, 0, absint( $count ) ) : [];
		}

		return [
			'code'    => '500',
			'message' => esc_html__( 'Error connecting to the AAWP API', 'aawp' ),
		];
	}

	/**
	 * Building HTML markup for search. Very similar to template.
	 * Existing template should be re-factored to make sure we use same search template for both Amazon & our own API.
	 *
	 * @param string $keyword The keyword searched for.
	 *
	 * @see '../includes/admin/templates/ajax-search-results.php';
	 *
	 * @since 3.30.0
	 */
	public function build_template( $keyword ) { //phpcs:ignore Generic.Metrics.CyclomaticComplexity.MaxExceeded

		$products = $this->get_products( $keyword, 10 );

		// In case the response has any message, show message instead.
		if ( ! empty( $products['code'] ) && ! empty( $products['message'] ) ) {

			$message = esc_html( $products['message'] );

			return '<p class="aawp-notice aawp-notice--error">' . esc_html( $products['code'] ) . ': ' . $message . '</p>';
		}

		// In edge cases.
		if ( empty( $products ) ) {
			return '<p class="aawp-notice aawp-notice--info">' . __( 'No products found.', 'aawp' ) . '</p>';
		}

		$html = '<div class="aawp-ajax-search-items">';
		foreach ( $products as $product ) {

			if ( empty( $product['asin'] ) || empty( $product['title'] ) || empty( $product['image'] ) ) {
				continue;
			}

			$price    = ! empty( $product['price']['raw'] ) ? $product['price']['raw'] : '';
			$is_prime = ! empty( $product['is_prime'] );

			ob_start();
			?>

			<div class="aawp-ajax-search-item" data-aawp-ajax-search-item="<?php echo esc_attr( $product['asin'] ); ?>">
				<span class="aawp-ajax-search-item__thumb">
					<img src="<?php echo esc_url( $product['image'] ); ?>" alt="thumbnail" />
				</span>
				
				<span class="aawp-ajax-search-item__content">
					<span class="aawp-ajax-search-item__title">
						<?php echo aawp_truncate_string( esc_html( $product['title'] ), 40 ); ?>
					</span>
					
					<?php if ( ! empty( $price ) ) { ?>
						<span class="aawp-ajax-search-item__price">
							<?php echo esc_html( $price ); ?>
								<?php if ( $is_prime ) { ?>
									<span class="aawp-check-prime"></span>
								<?php } ?>
						</span>
					<?php } ?>
				</span>
			</div>
			<?php

			$html .= ob_get_clean();
		}//end foreach

		$html .= '</div>';

		return ! empty( $html ) ? $html : '';
	}
}