<?php

namespace AAWP\API;

/**
 * Test an API Connection.
 */
class Test {

	/**
	 * Test API Endpoint.
	 *
	 * @var $endpoint The test API endpoint.
	 */
	private $endpoint = 'https://api.getaawp.com/v1/test/product';

	/**
	 * Initialize Test.
	 */
	public function init() {

		if ( defined( 'AAWP_API_URL' ) ) {
			$this->endpoint = AAWP_API_URL . '/test/product';
		}

		add_action( 'aawp_test_api_connection', [ $this, 'process' ] );
		add_action( 'aawp_settings_process', [ $this, 'pre_process' ] );
	}

	/**
	 * Pre-processing the test connection on AAWP API settings page save.
	 *
	 * @param array $post_data $_POST data in the process of saving settings.
	 */
	public function pre_process( $post_data ) {

		if ( 'aawp_aawp_api' !== $post_data['option_page'] || empty( $post_data['aawp_aawp_api']['connect'] ) ) {
			return;
		}

		$this->process( false, $post_data );
	}

	/**
	 * Process a test connection.
	 *
	 * @param bool $if_error Process only if the connection is already broken which happens for background checks.
	 */
	public function process( $if_error = true, $post_data = '' ) { //phpcs:ignore Generic.Metrics.CyclomaticComplexity.MaxExceeded

		if ( $if_error && empty( get_option( 'aawp_products_api_error' ) ) ) {
			return;
		}

	    $license_key = aawp_fs()->_get_license()->secret_key ?? '';

		if ( ! $if_error && is_array( $post_data ) ) {
			$aawp_api_key = $post_data['aawp_aawp_api']['key'] ?? '';
		} else {
			$aawp_api_key = aawp_get_option( 'key', 'aawp_api' );
		}

	    $auth_key   = ! empty( $aawp_api_key ) ? $aawp_api_key : $license_key;
	    $is_api_key = ! empty( $aawp_api_key ) ? '1' : '0';

		$options = [
			'headers' => [
				'Content-Type'     => 'application/json',
				'Authorization'    => $auth_key,
				'Is-AAWP-API-Key'  => $is_api_key,
				'AAWP-Version'     => AAWP_VERSION,
			],
		];

		$response = wp_remote_post( $this->endpoint, $options );

		if ( is_wp_error( $response ) ) {
			aawp_log(
				'AAWP Product API',
				'<code>' . esc_html( $response->get_error_message() ) . '</code>'
			);
			return;
		}

		$body_raw  = wp_remote_retrieve_body( $response );
		$http_code = wp_remote_retrieve_response_code( $response );
		$body_json = json_decode( $body_raw, true );

		if ( json_last_error() === JSON_ERROR_NONE ) {
			$code    = ! empty( $body_json['code'] ) ? absint( $body_json['code'] ) : 0;
			$message = ! empty( $body_json['message'] ) ? $body_json['message'] : esc_html__( 'An unexpected error occurred. Please try fetching products again.', 'aawp' );

			// Update option only if not 200.
			if ( $code != 200 && $code != 404 ) { //phpcs:ignore Universal.Operators.StrictComparisons.LooseNotEqual
				// 404 Error code means products not found.
				update_option( 'aawp_products_api_error', $code . ': ' . $message );
			} else {
				delete_option( 'aawp_products_api_error' );
			}
		}

		if ( $http_code !== 200 ) {
			aawp_log(
				'AAWP Product API',
				'<code>' . wp_strip_all_tags( $body_raw ) . '</code>'
			);
		}
	}
}