<?php

namespace AAWP\Admin;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

global $aawp_settings_page_slug;

/**
 * Settings Class.
 */
class Settings {

	private $current_tab          = ''; // phpcs:ignore Squiz.Commenting.VariableComment.Missing
	private $plugin_settings_tabs = []; // phpcs:ignore Squiz.Commenting.VariableComment.Missing

	/**
	 * Construct the plugin object
	 */
	public function __construct() {

		if ( isset( $_GET['tab'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			$this->current_tab = sanitize_text_field( wp_unslash( $_GET['tab'] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		} elseif ( \aawp_is_user_admin() ) {
			$this->current_tab = 'api';
		} else {
			$this->current_tab = 'general';
		}

		// Init menu and settings.
		global $aawp_settings_page_slug;

		$aawp_settings_page_slug = 'aawp-settings';

		add_action( 'aawp_admin_menu', [ &$this, 'add_settings_menu' ], 40 );
		add_action( 'admin_init', [ &$this, 'settings_init' ] );
		add_action( 'admin_init', [ $this, 'settings_process' ] );
	}

	/**
	 * Add settings menu.
	 *
	 * @param string $menu_slug Main Menu Slug.
	 *
	 * @see https://developer.wordpress.org/reference/functions/add_submenu_page/
	 */
	public function add_settings_menu( $menu_slug ) {

		$menu_cap            = apply_filters( 'aawp_admin_menu_cap', 'edit_pages' );
		$menu_settings_title = aawp_get_option( 'status', 'api' ) || aawp_get_option( 'connect', 'aawp_api' ) ? __( 'Settings', 'aawp' ) : '<span style="color: red;">' . __( 'Settings', 'aawp' ) . '</span>';

		add_submenu_page(
			$menu_slug,
			__( 'AAWP - Settings', 'aawp' ),
			$menu_settings_title,
			$menu_cap,
			'aawp-settings',
			[ $this, 'render_settings_page' ]
		);
	}

	/**
	 * Settings init
	 *
	 * @access      Public
	 * @since       2.0.0
	 * @return      void
	 */
	public function settings_init() {

		// Build tabs.
		$tabs = [];
		$tabs = apply_filters( 'aawp_settings_tabs', $tabs );

		foreach ( $tabs as $key => $label ) {
			$this->plugin_settings_tabs[ $key ] = $label;
		}

		do_action( 'aawp_settings_register' );
	}

	/**
	 * Render Settings Page
	 *
	 * @access      public
	 * @since       2.0.0
	 * @return      void
	 */
	public function render_settings_page() {

		if ( ! aawp_is_user_editor() ) {
			wp_die( esc_html__( 'You do not have sufficient permissions to access this page.', 'aawp' ) );
		}

		$current_tab_url = add_query_arg( [ 'tab' => $this->current_tab ], admin_url( 'admin.php?page=aawp-settings' ) );

		?>
		<div class="wrap aawp-wrap">
			<h2>
				<?php esc_html_e( 'Settings', 'aawp' ); ?>
			</h2>

			<?php
			if ( isset( $_REQUEST['settings-updated'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
					aawp_log( 'Settings', esc_html__( 'Settings Updated!', 'aawp' ) );
				?>
					<div id="message" class="updated">
						<p><strong><?php esc_html_e( 'Settings updated.', 'aawp' ); ?></strong></p>
					</div>
				<?php } ?>

				<?php do_action( 'aawp_settings_notices' ); ?>

				<?php $this->plugin_options_tabs(); ?>
			
				<div class="aawp-settings-container">
					<form id="aawp-form-settings" method="post" action="<?php echo esc_url( admin_url( 'options.php' ) ); ?>">
						<?php wp_nonce_field( 'aawp_update_options', '_wpnonce_aawp_update_options' ); ?>
						<?php settings_fields( 'aawp_' . $this->current_tab ); ?>
						<?php do_settings_sections( 'aawp_' . $this->current_tab ); ?>

						<?php if ( ! in_array( $this->current_tab, [ 'licensing', 'info' ], true ) && aawp_is_user_admin() ) { ?>
						<p class="submit">
							<?php submit_button( '', 'primary', 'aawp_update_options', false ); ?>&nbsp;
						</p>
					</form>					
							<?php ( new Infoboxes() )->init(); ?>
				</div>
			<?php }//end if ?>
		</div>

		<div id="postbox-container-1" class="postbox-container">
			<div class="meta-box-sortables">
				<?php do_action( 'aawp_settings_infoboxes' ); ?>
			</div>
		</div>

		<?php
	}

	/**
	 * Renders our tabs in the plugin options page,
	 * walks through the object's tabs array and prints
	 * them one by one. Provides the heading for the
	 * plugin_options_page method.
	 */
	public function plugin_options_tabs() { // phpcs:ignore Generic.Metrics.CyclomaticComplexity.TooHigh

		ksort( $this->plugin_settings_tabs );

		$template = '<div id="aawp-settings-tabs">  <h2 class="nav-tab-wrapper">';

		foreach ( $this->plugin_settings_tabs as $tab ) {

			if ( empty( $tab['key'] ) || empty( $tab['title'] ) ) {
				continue;
			}

			$template .= '<a href=" ' . esc_url( admin_url( 'admin.php?page=aawp-settings&tab=' . $tab['key'] ) ) . ' " class="nav-tab aawp-settings-tabs__link ' . ( $this->current_tab === $tab['key'] ? 'nav-tab-active' : '' ) . ( isset( $tab['alert'] ) ? ' aawp-settings-tabs__link--' . $tab['alert'] : '' ) . '" ><span class="dashicons dashicons-'. $tab['icon'] .'"></span>' . esc_html( $tab['title'] ) . '</a>';
		}

		$template .= '</h2></div>';

		// phpcs:ignore
		echo $template;
	}

	/**
	 * Settings process. The settings are saved automatically because they're created with "settings_fields()"
	 * and uses the Options API. This method helps to do something with POST data before saving the settings.
	 *
	 * @since 3.30.11
	 */
	public function settings_process() {

		// Bail if the user don't have required capabilities.
		if ( ! aawp_is_user_editor() ) {
			return;
		}

		$nonce = isset( $_REQUEST['_wpnonce_aawp_update_options'] ) ? sanitize_key( $_REQUEST['_wpnonce_aawp_update_options'] ) : '';

		if ( ! wp_verify_nonce( $nonce, 'aawp_update_options' ) ) {
			return;
		}

		// A hook before saving the settings.
		do_action( 'aawp_settings_process', $_POST );
	}
}
