<?php

namespace AAWP\Admin\Tools\Migrations;

/**
 * Amalinks Pro Migration.
 *
 * @since 4.3.3
 */
class Amalinkspro {

	/**
	 * Initalize.
	 */
	public function init() {
		add_action( 'aawp_process_amalinkspro_migration', [ $this, 'process_migration' ] );
		add_action( 'aawp_amalinkspro_migration_posts', [ $this, 'migrate_post_content' ] );
		add_action( 'aawp_amalinkspro_migration_widgets', [ $this, 'processing_widget_migrate' ] );
	}

	/**
	 * Process migration.
	 */
	public function process_migration() {
		aawp_log( 'Amalinks Pro Migration', __( 'Starting Amalinks Pro migration...', 'aawp' ) );

		$this->migrate_settings();

		$posts_with_shortcode = get_posts(
			[
				'post_type'      => 'any',
				'posts_per_page' => -1,
				's'              => '[amalinkspro_autoshowcase',
				'fields'         => 'ids',
			]
		);

		if ( empty( $posts_with_shortcode ) ) {
			aawp_log( 'Amalinks Pro Migration', __( 'No posts found with Amalinks Pro shortcode.', 'aawp' ) );
		} else {

			aawp_log( 'Amalinks Pro Migration', sprintf( /* translators: %s - number of posts */ __( 'Found %d posts with Amalinks Pro shortcode.', 'aawp' ), count( $posts_with_shortcode ) ) );

			foreach ( $posts_with_shortcode as $post_id ) {
				as_enqueue_async_action( 'aawp_amalinkspro_migration_posts', [ 'post_id' => $post_id ], 'aawp' );
			}
		}

		aawp_log( 'Amalinks Pro Migration', __( 'Migrating widgets containing Amalinks Pro shortcode...', 'aawp' ) );

		$this->migrate_widgets();

		aawp_log( 'Amalinks Pro Migration', __( 'Amalinks Pro migration completed.', 'aawp' ) );
	}

	/**
	 * Migrate a single post's content.
	 *
	 * @param int $post_id Post ID.
	 */
	public function migrate_post_content( $post_id ) {

		aawp_log( 'Amalinks Pro Migration', sprintf( /* translators: %s - Post ID */ __( 'Processing Post ID <code>%s</code>', 'aawp' ), $post_id ) );
		$post = get_post( $post_id );
		if ( ! $post ) {
			aawp_log( 'Amalinks Pro Migration', sprintf( /* translators: %s - Post ID */ __( 'Failed to get Post ID <code>%s</code>', 'aawp' ), $post_id ) );
			return;
		}

		$content     = $post->post_content;
		$new_content = $this->convert_amalinks_shortcode( $content );

		if ( $new_content !== $content ) {
			$result = wp_update_post(
				[
					'ID'           => $post_id,
					'post_content' => $new_content,
				]
			);

			if ( is_wp_error( $result ) ) {
				aawp_log( 'Amalinks Pro Migration', sprintf( /* translators: %s - Post ID */ __( 'Failed to update Post ID <code>%1$s</code>: %2$s', 'aawp' ), $post_id, $result->get_error_message() ) );
			} else {
				aawp_log( 'Amalinks Pro Migration', sprintf( /* translators: %s - Post ID */ __( 'Successfully migrated Post ID <code>%s</code>', 'aawp' ), $post_id ) );
			}
		} else {
			aawp_log( 'Amalinks Pro Migration', sprintf( /* translators: %s - Post ID */ __( 'No shortcode changes needed for Post ID <code>%s</code>', 'aawp' ), $post_id ) );
		}
	}

	/**
	 * Migrate widgets containing the shortcode.
	 */
	protected function migrate_widgets() { //phpcs:ignore Generic.Metrics.CyclomaticComplexity.MaxExceeded, Generic.Metrics.NestingLevel.MaxExceeded
		global $wpdb;

		// Get all widgets that contain [amalinkspro_autoshowcase].
		$widgets = $wpdb->get_results( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.DirectDatabaseQuery.DirectQuery
			$wpdb->prepare(
				"
                SELECT option_name, option_value
                FROM {$wpdb->options}
                WHERE option_name LIKE %s
                AND option_value LIKE %s
                ",
				'%widget_%',
				'%' . $wpdb->esc_like( 'amalinkspro_autoshowcase' ) . '%'
			),
			ARRAY_A
		);

		$migrated_widgets = 0;

		// Loop through each widget option.
		foreach ( $widgets as $widget ) {
			++$migrated_widgets;
			as_enqueue_async_action( 'aawp_amalinkspro_migration_widgets', [ 'widget' => $widget['option_name'] ], 'aawp' );
		}

		aawp_log( 'Amalinks Pro Migration', sprintf( /* translators: %s - number of widgets */ __( 'Completed migrating %d widgets.', 'aawp' ), $migrated_widgets ) );
	}

	/**
	 * Processing widget migrate.
	 *
	 * @param string $option_name Option Name.
	 *
	 * @since 4.0.0
	 */
	public function processing_widget_migrate( $option_name ) {

		$option_value = maybe_unserialize( get_option( $option_name, [] ) );

		$updated = false;

		// Recursively scan and migrate all strings containing the shortcode.
		$option_value = $this->migrate_widget_instance_recursive( $option_value, $option_name, $updated );

		if ( $updated ) {
			update_option( $option_name, $option_value );
			aawp_log( 'Amalinks Pro Migration', sprintf( 'Migrated shortcode in widget option <code>%s</code>', $option_name ) );
		}
	}

	/**
	 * Convert AmalinksPro shortcode to Amazon shortcode.
	 *
	 * @param string $content Post Content.
	 * @return string
	 */
	protected function convert_amalinks_shortcode( $content ) { //phpcs:ignore Generic.Metrics.CyclomaticComplexity.MaxExceeded, Generic.Metrics.CyclomaticComplexity.MaxExceeded
		return preg_replace_callback(
			'/\[amalinkspro_autoshowcase\s+([^\]]+)\]/',
			function ( $matches ) {
				$atts_str = $matches[1];
				preg_match_all( '/([\w-]+)\s*=\s*"([^"]*)"/', $atts_str, $attr_matches, PREG_SET_ORDER );
				$atts = [];
				foreach ( $attr_matches as $match ) {
					$atts[ $match[1] ] = $match[2];
				}

				$amazon_atts = [];
				if ( ! empty( $atts['asin'] ) ) {
					$amazon_atts['box'] = $atts['asin'];
				}
				if ( ! empty( $atts['product-title'] ) ) {
					$amazon_atts['title'] = $atts['product-title'];
				}
				if ( ! empty( $atts['description'] ) ) {
					$amazon_atts['description'] = $atts['description'];
				}
				if ( ! empty( $atts['button-text'] ) ) {
					$amazon_atts['button_text'] = $atts['button-text'];
				}
				if ( ! empty( $atts['banner'] ) ) {
					$amazon_atts['sale_ribbon_text'] = $atts['banner'];
				}
				if ( isset( $atts['hide-button'] ) ) {
					$amazon_atts['button'] = $atts['hide-button'] === 'true' ? 'none' : 'button';
				}
				if ( isset( $atts['hide-price'] ) ) {
					$amazon_atts['price'] = $atts['hide-price'] === 'true' ? '' : 'price';
				}
				if ( ! empty( $atts['image-alt'] ) ) {
					$amazon_atts['image_alt'] = $atts['image-alt'];
				}

				$new_shortcode = '[amazon';
				foreach ( $amazon_atts as $key => $value ) {
					$new_shortcode .= ' ' . $key . '="' . $value . '"';
				}
				$new_shortcode .= ']';

				return $new_shortcode;
			},
			$content
		);
	}

	/**
	 * Migrate widget instance.
	 *
	 * @param array  $instance  Widget Instance.
	 * @param string $widget_id Widget ID.
	 * @param bool   $updated   If it's updated.
	 */
	protected function migrate_widget_instance_recursive( $instance, $widget_id, &$updated ) {
		foreach ( $instance as $key => $value ) {
			if ( is_string( $value ) && str_contains( $value, '[amalinkspro_autoshowcase' ) ) {
				aawp_log( 'Amalinks Pro Migration', sprintf( 'Migrating shortcode in Widget ID <code>%s</code>, field "%s"', $widget_id, $key ) );
				$instance[ $key ] = $this->convert_amalinks_shortcode( $value );
				$updated          = true;
			} elseif ( is_array( $value ) ) {
				$instance[ $key ] = $this->migrate_widget_instance_recursive( $value, $widget_id, $updated );
			}
		}
		return $instance;
	}

	/**
	 * Migration some of the settings such as API Key, Secret Key, Country and Tracking ID.
	 *
	 * @since 4.3.3
	 */
	public function migrate_settings() {

		// Bail if AAWP is already connected.
		if ( ! empty( aawp_get_option( 'status', 'api' )) ) {
			return;
		}

		$locale = get_option( 'amalinkspro-options_default_amazon_search_locale' );

		$aawp_api            = get_option( 'aawp_api', [] );
		$aawp_api['key']     = get_option( 'amalinkspro-options_amazon_api_access_key' );
		$aawp_api['secret']  = get_option( 'amalinkspro-options_amazon_api_secret_key' );
		$aawp_api['country'] = $locale;

		$associate_option_name     = "amalinkspro-options_{$locale}_amazon_associate_ids_0_associate_id";
		$aawp_api['associate_tag'] = get_option( $associate_option_name );

		update_option( 'aawp_api', $aawp_api );

		$aawp_aawp_api            = get_option( 'aawp_aawp_api', [] );
		$aawp_aawp_api['connect'] = get_option( 'amalinkspro-options_alp_no_amazon_api' );
		update_option( 'aawp_aawp_api', $aawp_aawp_api );
	}
}
