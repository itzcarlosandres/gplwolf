<?php

namespace AAWP\Admin;

/**
 * Site Health.
 *
 * @since 3.32.0
 */
class SiteHealth {

	/**
	 * Indicate if Site Health is allowed to load.
	 *
	 * @since 3.32.0
	 *
	 * @return bool
	 */
	private function allow_load() {

		global $wp_version;

		return version_compare( $wp_version, '5.2', '>=' );
	}

	/**
	 * Init Site Health.
	 *
	 * @since 3.32.0
	 */
	final public function init() {

		if ( ! $this->allow_load() ) {
			return;
		}

		$this->hooks();
	}

	/**
	 * Integration hooks.
	 *
	 * @since 3.32.0
	 */
	protected function hooks() {

		add_filter( 'debug_information', [ $this, 'add_info_section' ] );
		add_filter( 'site_status_tests', [ $this, 'tests' ] );
	}

	/**
	 * Add AAWP section to Info tab.
	 *
	 * @since 3.32.0
	 *
	 * @param array $debug_info Array of all information.
	 *
	 * @return array Array with added AAWP info section.
	 */
	public function add_info_section( $debug_info ) { // phpcs:ignore Generic.Metrics.CyclomaticComplexity.TooHigh

		$aawp = [
			'label'  => 'AAWP',
			'fields' => [
				'version' => [
					'label' => esc_html__( 'Version', 'aawp' ),
					'value' => AAWP_VERSION,
				],
			],
		];

		$aawp['fields']['products'] = [
			'label' => esc_html__( 'Products', 'aawp' ),
			'value' => aawp_get_products_count(),
		];

		$aawp['fields']['lists'] = [
			'label' => esc_html__( 'Lists', 'aawp' ),
			'value' => aawp_get_lists_count(),
		];

		$aawp['fields']['last_update'] = [
			'label' => esc_html__( 'Last Update', 'aawp' ),
			'value' => aawp_datetime( aawp_get_cache_last_update() ),
		];

		$aawp['fields']['mbstring'] = [
			'label' => esc_html__( 'PHP "mbstring" extension', 'aawp' ),
			'value' => extension_loaded( 'mbstring' ) ? 'Enabled' : 'Disabled',
		];

		$aawp['fields']['allow_url_fopen'] = [
			'label' => esc_html__( 'PHP "allow_url_fopen" setting', 'aawp' ),
			'value' => ini_get( 'allow_url_fopen' ) ? 'Enabled' : 'Disabled',
		];

		$debug_info['aawp'] = $aawp;

		return $debug_info;
	}

	/**
	 * Add or modify which site status tests are run on a site.
	 *
	 * @since 3.32.0
	 *
	 * @param array $tests Site health tests registered.
	 *
	 * @return array
	 */
	public function tests( $tests ) {

		$tests['direct']['aawp_license'] = [
			'label' => esc_html__( 'AAWP License', 'aawp' ),
			'test'  => [ $this, 'license_check' ],
		];

		$tests['direct']['aawp_allow_url_fopen'] = [
			'label' => esc_html__( 'AAWP - allow_url_fopen() check', 'aawp' ),
			'test'  => [ $this, 'allow_url_fopen_check' ],
		];

		$tests['direct']['aawp_mbstring'] = [
			'label' => esc_html__( 'AAWP - mbstring check', 'aawp' ),
			'test'  => [ $this, 'mbstring_check' ],
		];

		$tests['direct']['aawp_curl'] = [
			'label' => esc_html__( 'AAWP - cURL check', 'aawp' ),
			'test'  => [ $this, 'curl_check' ],
		];

		$tests['direct']['aawp_openssl'] = [
			'label' => esc_html__( 'AAWP - Open SSL check', 'aawp' ),
			'test'  => [ $this, 'openssl_check' ],
		];

		return $tests;
	}

	/**
	 * License Checks.
	 *
	 * @param $tests array Tests.
	 *
	 * @since 3.32.0
	 */
	public function license_check() {

		$result = [
			'label'       => sprintf( /* translators: %s license status */
				esc_html__( 'Your AAWP license is %s', 'aawp' ),
				aawp_fs()->is_paying() ? 'valid' : 'invalid'
			),
			'status'      => aawp_fs()->is_paying() ? 'good' : 'critical',
			'badge'       => [
				'label' => esc_html__( 'Security', 'aawp' ),
				'color' => aawp_fs()->is_paying() ? 'blue' : 'red',
			],
			'description' => sprintf(
				'<p>%s</p>',
				esc_html__( 'You have access to updates and support.', 'aawp' )
			),
			'actions'     => '',
			'test'        => 'aawp_license',
		];

		if ( aawp_fs()->is_paying() ) {
			return $result;
		}

		$result['description'] = esc_html__( '❌ A valid AAWP license is required.', 'aawp' );

		$result['actions'] = sprintf(
			'<p><a href="%s">%s</a></p>',
			admin_url( 'admin.php?page=aawp-settings&tab=licensing' ),
			esc_html__( 'Enter a valid AAWP License.', 'aawp' )
		);

		return $result;
	}

	/**
	 * "allow_url_fopen" PHP Extension Check.
	 *
	 * @since 3.32.0
	 */
	public function allow_url_fopen_check() {

		$allow_url_fopen = ini_get( 'allow_url_fopen' );

		$result = [
			'label'       => sprintf( /* translators: %s allow_url_fopen() status */
				esc_html__( 'PHP Extension allow_url_fopen() is %s', 'aawp' ),
				$allow_url_fopen ? 'enabled' : 'disabled'
			),
			'status'      => $allow_url_fopen ? 'good' : 'critical',
			'badge'       => [
				'label' => esc_html__( 'AAWP', 'aawp' ),
				'color' => $allow_url_fopen ? 'blue' : 'red',
			],
			'description' => sprintf(
				'<p>%s</p>',
				esc_html__( 'allow_url_fopen() is required for certain AAWP features to work.', 'aawp' )
			),
			'actions'     => '',
			'test'        => 'aawp_allow_url_fopen',
		];

		if ( $allow_url_fopen ) {
			return $result;
		}

		$result['description'] = esc_html__( '❌ PHP Extension allow_url_fopen() is not enabled. It is required for certain features of AAWP Plugin.', 'aawp' );

		return $result;
	}

	/**
	 * "mbstring" PHP Extension Check.
	 *
	 * @since 3.32.0
	 */
	public function mbstring_check() {

		$mbstring = extension_loaded( 'mbstring' );

		$result = [
			'label'       => sprintf( /* translators: %s mbstring() status */
				esc_html__( 'PHP Extension mbstring is %s', 'aawp' ),
				$mbstring ? 'enabled' : 'disabled'
			),
			'status'      => $mbstring ? 'good' : 'critical',
			'badge'       => [
				'label' => esc_html__( 'AAWP', 'aawp' ),
				'color' => $mbstring ? 'blue' : 'red',
			],
			'description' => sprintf(
				'<p>%s</p>',
				esc_html__( 'mbstring PHP Extension is required for certain AAWP features to work.', 'aawp' )
			),
			'actions'     => '',
			'test'        => 'aawp_mbstring',
		];

		if ( $mbstring ) {
			return $result;
		}

		$result['description'] = esc_html__( '❌ PHP Extension mbstring is not enabled. It is required for certain features of AAWP Plugin.', 'aawp' );

		return $result;
	}

	/**
	 * Check if cURL extension is greater than 7.64.0 or higher.
	 *
	 * @since 4.2.0
	 */
	public function curl_check() {

		$curl = function_exists('curl_version') && version_compare( curl_version()['version'], '7.64.0', '>=' );

		$result = [
			'label'       => sprintf( /* translators: %s curl status */
				esc_html__( 'PHP Extension curl %s', 'aawp' ),
				$curl ? 'enabled' : esc_html__( 'has issues.', 'aawp' )
			),
			'status'      => $curl ? 'good' : 'critical',
			'badge'       => [
				'label' => esc_html__( 'AAWP', 'aawp' ),
				'color' => $curl ? 'blue' : 'red',
			],
			'description' => sprintf(
				'<p>%s</p>',
				esc_html__( 'cURL PHP Extension should be greater than v7.64.0 for certain AAWP features to work.', 'aawp' )
			),
			'actions'     => '',
			'test'        => 'aawp_curl',
		];

		return $result;
	}

	/**
	 * Check open SSL PHP Extension.
	 *
	 * @since 4.2.0
	 */
	public function openssl_check() {

		$openssl = extension_loaded( 'openssl' );

		$result = [
			'label'       => sprintf( /* translators: %s Open SSL status */
				esc_html__( 'PHP Extension Open SSL %s', 'aawp' ),
				$openssl ? 'enabled' : 'disabled'
			),
			'status'      => $openssl ? 'good' : 'critical',
			'badge'       => [
				'label' => esc_html__( 'AAWP', 'aawp' ),
				'color' => $openssl ? 'blue' : 'red',
			],
			'description' => sprintf(
				'<p>%s</p>',
				esc_html__( 'Open SSL PHP Extension should be enabled for certain AAWP features to work.', 'aawp' )
			),
			'actions'     => '',
			'test'        => 'aawp_openssl',
		];

		return $result;
	}
}
