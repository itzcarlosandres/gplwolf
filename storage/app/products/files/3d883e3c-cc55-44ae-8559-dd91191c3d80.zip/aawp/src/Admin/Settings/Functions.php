<?php

namespace AAWP\Admin\Settings;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class for the Functions tab within the settings.
 */
class Functions extends \AAWP_Functions {

	/**
	 * Construct the plugin object
	 */
	public function __construct() {

		// Call parent constructor first.
		parent::__construct();

		// Setup identifier.
		$this->func_order = 30;
		$this->func_id    = 'functions';

		// Settings functions.
		add_filter( $this->settings_tabs_filter, [ &$this, 'add_settings_tabs_filter' ] );
		add_filter( $this->settings_functions_filter, [ &$this, 'add_settings_functions_filter' ] );

		add_action( 'admin_init', [ &$this, 'add_settings' ] );
	}

	/**
	 * Add settings functions.
	 *
	 * @param array $tabs The other tabs.
	 */
	public function add_settings_tabs_filter( $tabs ) {

		$tabs[ $this->func_order ] = [
			'key'   => $this->func_id,
			'icon'  => 'cover-image',
			'title' => __( 'Functions', 'aawp' ),
		];

		return $tabs;
	}

	/**
	 * Add functions to the settings.
	 *
	 * @param array $functions An array of other functions.
	 */
	public function add_settings_functions_filter( $functions ) {

		$functions[] = $this->func_id;

		return $functions;
	}

	/**
	 * Settings: Register section and fields
	 */
	public function add_settings() {

		register_setting( 'aawp_functions', 'aawp_functions', [ 'sanitize_callback' => 'aawp_sanitize_settings_fields'] );

		add_settings_section(
			'aawp_functions_section',
			'',
			'',
			'aawp_functions'
		);

		/*
		 * Action to add more settings within this section
		 */
		do_action( 'aawp_settings_functions_register' );
	}
}
