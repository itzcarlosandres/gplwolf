<?php

namespace AAWP\Admin;

/**
 * Infoboxes.
 *
 * @since 3.42
 */
class Infoboxes {

	/**
	 * Initialize.
	 */
	public function init() {

		$this->add_boxes();
	}

	/**
	 * Add boxes to the sidebar like "Our Other Products"
	 *
	 * @since 3.42
	 */
	public function add_boxes() {
		ob_start();
		?>
		<div class="aawp-settings-widget">

			<div class="aawp-settings-box">
				<div class="hero">
					<img src="<?php echo esc_url( AAWP_PLUGIN_URL . 'assets/img/widget-docs.png' ); ?>"
						alt="documentation">
				</div>
				<h3 class="title"><?php esc_attr_e( 'Plugin Documentation', 'aawp' ); ?></h3>
				<div class="inside">
					<ul>
						<li><a href="<?php echo esc_url( aawp_get_page_url( 'get-started' ) ); ?>"
							class="text"
							target="_blank"
							rel="nofollow"
							title="<?php esc_attr_e( 'Starting with AAWP: Main functions and how to use them', 'aawp' ); ?>"><?php esc_attr_e( 'Starting with AAWP: Main functions and how to use them', 'aawp' ); ?></a></li>
						<li><a href="<?php echo esc_url( aawp_get_page_url( 'comparison-tables' ) ); ?>"
							class="text"
							target="_blank"
							rel="nofollow"
							title="<?php esc_attr_e( 'Comparison Tables', 'aawp' ); ?>"><?php esc_attr_e( 'Comparison Tables', 'aawp' ); ?></a></li>
						<li><a href="<?php echo esc_url( aawp_get_page_url( 'docs:shortcodes' ) ); ?>"
							class="text"
							target="_blank"
							rel="nofollow"
							title="<?php esc_attr_e( 'Shortcodes and adjustment', 'aawp' ); ?>"><?php esc_attr_e( 'Shortcodes and adjustment', 'aawp' ); ?></a></li>
						<li><a href="<?php echo esc_url( aawp_get_page_url( 'docs:license_upgrades' ) ); ?>"
							class="text"
							target="_blank"
							rel="nofollow"
							title="<?php esc_attr_e( 'License Upgrades', 'aawp' ); ?>"><?php esc_attr_e( 'License Upgrades', 'aawp' ); ?></a></li>
						<li><a href="<?php echo esc_url( aawp_get_page_url( 'docs:api_keys' ) ); ?>"
							class="text"
							target="_blank"
							rel="nofollow"
							title="<?php esc_attr_e( 'Creating Credentials for Amazon Product Advertising API', 'aawp' ); ?>"><?php esc_attr_e( 'Creating Credentials for Amazon Product Advertising API', 'aawp' ); ?></a></li>
						<li><a href="<?php echo esc_url( aawp_get_page_url( 'docs:aawp-api' ) ); ?>"
							class="text"
							target="_blank"
							rel="nofollow"
							title="<?php esc_attr_e( 'AAWP API', 'aawp' ); ?>"><?php esc_attr_e( 'AAWP API', 'aawp' ); ?></a></li>
						<li><a href="<?php echo esc_url( aawp_get_page_url( 'docs:api_issues' ) ); ?>"
							class="text"
							target="_blank"
							rel="nofollow"
							title="<?php esc_attr_e( 'Amazon API “not connected” - Frequent causes', 'aawp' ); ?>"><?php esc_attr_e( 'Amazon API “not connected” - Frequent causes', 'aawp' ); ?></a></li>
						<li><a href="<?php echo esc_url( aawp_get_page_url( 'docs:ratings_info' ) ); ?>"
							class="text"
							target="_blank"
							rel="nofollow"
							title="<?php esc_attr_e( 'Star ratings and reviews don\'t show up', 'aawp' ); ?>"><?php esc_attr_e( 'Star ratings and reviews don\'t show up', 'aawp' ); ?></a></li>

						</ul>

					<div class="get-started">
						<a href="<?php echo aawp_is_lang_de() ? 'https://aawp.de/docs/' : 'https://getaawp.com/docs/'; ?>"
						class="aawp-get-started-btn"
						rel="noopener"
						target="_blank"><?php esc_attr_e( 'View all Articles', 'aawp' ); ?></a>
					</div>
				</div>
			</div>
			<div class="aawp-settings-box">
				<h2 class="aawp-settings-widget_title"><?php esc_html_e( 'Our Other Products', 'aawp' ); ?></h2>
				<p><?php esc_html_e( 'Like this plugin? Check out our other WordPress products:', 'aawp' ); ?></p>
				<div class="aawp-sidebar-other-products">
					<a href="https://clickwhale.pro/link-manager/?utm_source=aawp_customer_site&utm_medium=link&utm_campaign=plugin&utm_term=admin_settings&utm_content=our_products_links" target="_blank" rel="noopener noreferer">
						<div class="aawp-sidebar-product">
							<img src="<?php echo esc_url( AAWP_PLUGIN_URL . 'assets/img/img-clickwhale.svg' ); ?>" alt="Clickwhale">
							<p><strong>ClickWhale</strong><br/> <?php esc_html_e( 'Our link manager plugin to organize and analyze your affiliate links.', 'aawp' ); ?></p>
							<span class="aawp-sidebar-product-arrow">&#8594;</span>
						</div>
						</a>
					<hr/>
					<a href="https://mhthemes.com/themes/mh-magazine/?utm_source=aawp_customer_site&utm_medium=link&utm_campaign=plugin&utm_term=admin_settings&utm_content=our_products_links" target="_blank" rel="noopener noreferer">
						<div class="aawp-sidebar-product">
							<img src="<?php echo esc_url( AAWP_PLUGIN_URL . 'assets/img/img-mht.svg' ); ?>" alt="MH  Magazine">
							<p><strong>MH Magazine</strong><br/> <?php esc_html_e( 'Our premium theme focusing on news and magazine websites.', 'aawp' ); ?></p>
							<span class="aawp-sidebar-product-arrow">&#8594;</span>
						</div>
					</a>
				</div>
			</div>
		</div>
		<?php
		echo ob_get_clean(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}
}
