<?php

namespace AAWP\Admin\Settings;

use AAWP_Functions as Functions;

/**
 * Class for handling Geotargeting settings tab.
 *
 * @since 4.2.0
 */
class Geotargeting extends Functions {

	/**
	 * Construct the plugin object.
	 *
	 * @since 4.2.0
	 */
	public function __construct() {

		// Call parent constructor first.
		parent::__construct();

		// Setup identifier.
		$this->func_order = 35;
		$this->func_id    = 'geotargeting';

		add_filter( $this->settings_tabs_filter, [ &$this, 'add_settings_tabs_filter' ] );

		add_action( 'admin_init', [ $this, 'add_settings' ] );
	}

	/**
	 * Add Geotargeting tab.
	 *
	 * @param array $tabs Existing Tabs.
	 *
	 * @since 4.2.0
	 *
	 * @return array Tabs with Geotargeting.
	 */
	public function add_settings_tabs_filter( $tabs ) {

		$tabs[ $this->func_order ] = [
			'key'   => $this->func_id,
			'icon'  => 'admin-site',
			'title' => __( 'Geotargeting', 'aawp' ),
		];

		return $tabs;
	}

	/**
	 * Add settings in Geotargeting tab.
	 *
	 * @since 4.2.0
	 */
	public function add_settings() {

		register_setting( 'aawp_geotargeting', 'aawp_geotargeting', [ 'sanitize_callback' => 'aawp_sanitize_settings_fields'] );
		// @see https://developer.wordpress.org/reference/functions/register_setting/

		add_settings_section( 'aawp_geotargeting_section', '', '', 'aawp_geotargeting' );
		// @see https://developer.wordpress.org/reference/functions/add_settings_section/

		add_settings_field(
			'aawp_geotargeting',
			$this->settings_title(),
			'aawp_settings_geotargeting_render',
			'aawp_geotargeting',
			'aawp_geotargeting_section'
		);

		add_settings_field(
			'aawp_geotargeting_multiple_stores',
			__( 'Tracking IDs', 'aawp' ),
			'aawp_settings_api_multiple_stores_render',
			'aawp_geotargeting',
			'aawp_geotargeting_section',
			[ 'label_for' => 'aawp_geotargeting_multiple_stores' ]
		);
	}

	/**
	 * Render Settings Title.
	 *
	 * @since 4.2.0
	 */
	public function settings_title() {

		$title  = '<label>' . esc_html__( 'Geotargeting', 'aawp' ) . '</label>';
		$title .= '<p class="description">' . sprintf(
			/* translators: %s - Geotargeting documentation link. */
			esc_html__( 'The %s function automatically updates your links to the Amazon store of the site visitor. This allows you to earn more commission.', 'aawp' ),
			'<a href="' . aawp_get_page_url( 'docs:geotargeting' ) . '">' . esc_html__( 'geotargeting', 'aawp' ) . '</a>'
		) .
				'</p>';

		return $title;
	}
}
