<?php

namespace AAWP\Admin\Settings;

use AAWP_Functions as Functions;

/**
 * Class for handling AAWP API settings tab.
 *
 * @since 4.2.0
 */
class AAWP_API extends Functions {

	/**
	 * Construct the plugin object.
	 *
	 * @since 4.2.0
	 */
	public function __construct() {

		parent::__construct();

		$this->func_order = 12;
		$this->func_id    = 'aawp_api';

		add_filter( $this->settings_tabs_filter, [ &$this, 'add_settings_tabs_filter' ] );

		add_action( 'admin_init', [ $this, 'add_settings' ] );
	}

	/**
	 * Add AAWP API tab.
	 *
	 * @param array $tabs Existing Tabs.
	 *
	 * @since 4.2.0
	 *
	 * @return array Tabs with AAWP API.
	 */
	public function add_settings_tabs_filter( $tabs ) {

		$tabs[ $this->func_order ] = [
			'key'   => $this->func_id,
			'icon'  => is_aawp_api_active() ? 'plugins-checked' : 'admin-plugins',
			'title' => __( 'AAWP API', 'aawp' ),
		];

		return $tabs;
	}

	/**
	 * Add settings in AAWP API tab.
	 *
	 * @since 4.2.0
	 */
	public function add_settings() {

		register_setting( 'aawp_aawp_api', 'aawp_aawp_api', [ 'sanitize_callback' => 'aawp_sanitize_settings_fields' ] );
		// @see https://developer.wordpress.org/reference/functions/register_setting/

		add_settings_section( 'aawp_aawp_api_section', '', '', 'aawp_aawp_api' );
		// @see https://developer.wordpress.org/reference/functions/add_settings_section/

		/**
		 * AAWP API Headline Text section.
		 *
		 * @since 4.2.0
		 */
		add_settings_section(
			'aawp_aawp_api_section',
			__( '', 'Settings Section Headline', 'aawp' ),
			[ &$this, 'render_headline' ],
			'aawp_aawp_api'
		);

		/**
		 * AAWP API Connection Status.
		 *
		 * @since 4.2.0
		 */
		add_settings_field(
			'aawp_aawp_api_status',
			__( 'Status', 'aawp' ),
			[ $this, 'settings_aawp_aawp_api_status_render' ],
			'aawp_aawp_api',
			'aawp_aawp_api_section',
			[ 'label_for' => 'aawp_aawp_api_status' ]
		);

		/**
		 * AAWP API Key.
		 */
		add_settings_field(
			'aawp_aawp_api_key',
			__( 'API Key', 'aawp' ),
			[ &$this, 'settings_aawp_api_key_render' ],
			'aawp_aawp_api',
			'aawp_aawp_api_section',
			[ 'label_for' => 'aawp_aawp_api_key' ]
		);

		/**
		 * AAWP API Usage.
		 *
		 * @since 4.2.0
		 */
		add_settings_field(
			'aawp_aawp_api_usage',
			__( 'Usage Quota', 'aawp' ),
			[ $this, 'settings_aawp_aawp_api_usage_render' ],
			'aawp_aawp_api',
			'aawp_aawp_api_section',
			[ 'label_for' => 'aawp_aawp_api_usage' ]
		);

		add_settings_field(
			'aawp_aawp_api_country',
			__( 'Country', 'aawp' ),
			[ &$this, 'settings_aawp_api_country_render' ],
			'aawp_aawp_api',
			'aawp_aawp_api_section',
			[ 'label_for' => 'aawp_aawp_api_country' ]
		);

		add_settings_field(
			'aawp_aawp_api_associate_tag',
			__( 'Tracking ID', 'aawp' ),
			[ &$this, 'settings_aawp_api_associate_tag_render' ],
			'aawp_aawp_api',
			'aawp_aawp_api_section',
			[ 'label_for' => 'aawp_aawp_api_associate_tag' ]
		);
	}

	/**
	 * Render Settings Title.
	 *
	 * @since 4.2.0
	 */
	public function title() {

		$title  = '<label>' . esc_html__( 'AAWP API', 'aawp' ) . '</label>';
		$title .= '<p class="description">
                    <a href="' . aawp_get_page_url( 'docs:aawp-api' ) . '">' . esc_html__( 'Learn More', 'aawp' ) . '</a> 
				</p>';

		return $title;
	}

	/**
	 * Render headline text for AAWP API tab.
	 *
	 * @since 4.2.0
	 */
	public function render_headline() {
		?>
		<table>
			<tbody>
				<tr>
					<td>
						<?php echo '<label class="title">' . esc_html__( 'AAWP API', 'aawp' ) . '</label>'; ?>
						<p>
							<?php
								printf(
									esc_html__( 'If you do not have access to the official Amazon Product Advertising API, you can alternatively use our %s to retrieve product data.', 'aawp' ),
									'<a href="' . aawp_get_page_url( 'feature:aawp-api' ) . '" target="_blank" rel="nofollow noopener noreferrer">' . esc_html__( 'AAWP API', 'aawp' ) . '</a>'
								)
							 ?>
						</p>
						<p>
							<?php
							printf(
								esc_html__( 'Please note that access is limited both in terms of time and functionality. Once you have generated your first commissions via Amazon, we strongly advise you to switch to the %s to use the full functionality of our plugin.', 'aawp' ),
								'<a href="' . admin_url( 'admin.php?page=aawp-settings&tab=api' ) . '">' . esc_html__( 'official Amazon API', 'aawp' ) . '</a>'
							);
							?>
						</p>
						<p>
							<strong><?php echo esc_html__( 'Documentation:', 'aawp' ); ?></strong>
							<a href="<?php echo aawp_get_page_url( 'docs:aawp-api' ); ?>" title="<?php _e( 'AAWP API', 'aawp' ); ?>" target="_blank" rel="noopener noreferrer"><?php _e( 'AAWP API', 'aawp' ); ?></a>
						</p>
					</td>
				</tr>
			</tbody>
		</table>
		<?php
	}

	/**
	 * Section for AAWP API status.
	 *
	 * @since 4.2.0
	 */
	public function settings_aawp_aawp_api_status_render() {

		$options_api     = aawp_get_options( 'aawp_api' );
		$connect         = ! empty( $options_api['connect'] );
		$connect_error   = get_option( 'aawp_products_api_error' );
		$disconnect_text = '<span class="aawp-aawp-api-disconnected message error">' . __( 'Disconnected', 'aawp' ) . '</span>';

		echo is_aawp_api_active()
			? '<span class="aawp-aawp-api-connected message success">' . __( 'Connected', 'aawp' ) . '</span>'
			: $disconnect_text;

		if ( $connect ) {
			submit_button( __( 'Reconnect', 'aawp' ), 'aawp-aawp-api-reconnect button-secondary button-small', 'aawp_aawp_api[reconnect]', false );
		}

		if ( ! empty( aawp_get_option( 'status', 'api' ) ) ) {
			$connect_error = __( '409: Amazon API already connected.', 'aawp' );
		}

		if ( empty( $options_api['associate_tag'] ) ) {
			$connect_error = __( '400: Tracking ID is required to assign conversions to your affiliate account.', 'aawp' );
		}

		if ( $connect && ! empty( $connect_error ) ) {
			echo '<p class="aawp-aawp-api-connect-error message error">';
			echo esc_html__( 'Error', 'aawp' ) . ' ' . esc_html( $connect_error );
			echo '</p>';
		} elseif ( $connect && isset( $options_api['key'] ) && empty( $options_api['key'] ) ) {
			echo '<p class="aawp-aawp-api-connect-error message error">';
			echo esc_html__( 'Please enter your AAWP API Key.', 'aawp' );
			echo '</p>';
		}

		echo $this->settings_aawp_aawp_api_connect_render();
	}

	/**
	 * Checkbox for connecting to AAWP API.
	 *
	 * @since 3.30
	 */
	public function settings_aawp_aawp_api_connect_render() { //phpcs:ignore Generic.Metrics.CyclomaticComplexity.MaxExceeded

		$options_api = aawp_get_options( 'aawp_api' );
		$connect     = ! empty( $options_api['connect'] );
		?>
		<div class="aawp-aawp-api-connect">
			<p>
				<input type="checkbox" id="aawp_api_connect" name="aawp_aawp_api[connect]" value="1" <?php echo( $connect ? 'checked' : '' ); ?> />
				<label for="aawp_api_connect"><?php esc_html_e( 'Check to retrieve products from the AAWP API instead of the Amazon API.', 'aawp' ); ?></label>
			</p>
			<p class="message info">
				<?php
				printf(
					/* translators: %s - AAWP API documentation link */
					esc_html__( 'Activate only if you can\'t retrieve products from the official Amazon API yet. More information about the AAWP API can be found %s.', 'aawp' ),
					'<a href="' . aawp_get_page_url( 'docs:aawp-api' ) . '" target="_blank" rel="nofollow noopener noreferrer">here</a>'
				);
				?>
			</p>
		</div>
		<?php
	}

	/**
	 * Settings for AAWP API Key.
	 *
	 * @since 5.0.0
	 */
	public function settings_aawp_api_key_render() {

		$key = ( isset( $this->options['aawp_api']['key'] ) ) ? esc_attr( $this->options['aawp_api']['key'] ) : '';

		?>
		<input type="password" id="aawp_api_key" class="regular-text" name="aawp_aawp_api[key]" value="<?php echo $key; ?>" 
																															<?php
																															if ( ! aawp_is_user_admin() ) {
																																echo 'readonly';}
																															?>
		/>
		<p class="message info">
			<?php
				printf(
					/* translators: %1s - AAWP API feature page link, %2s - link to the customer account page. */
					esc_html__( 'Use of the AAWP API is charged and access can be %1s. If you have already purchased access, you will find your personal API key in your %2s.', 'aawp' ),
					'<a href="' . esc_url( aawp_get_page_url( 'feature:aawp-api' ) ) . '" target="_blank" rel="nofollow noopener noreferrer">' . esc_html__( 'purchased here', 'aawp' ) . '</a>',
					'<a href="' . esc_url( aawp_get_page_url( 'account' ) ) . '" target="_blank" rel="nofollow noopener noreferrer">' . esc_html__( 'customer account', 'aawp' ) . '</a>'
				);
			?>
		</p>
		<p class="message info">
			<?php
				echo esc_html__( 'Important: This is not your AAWP plugin license key.', 'aawp ' );
			?>
		</p>
		<?php
	}

	/**
	 * Settings AAWP API usage render.
	 */
	public function settings_aawp_aawp_api_usage_render() {

		$usage_count      = (int) get_option( 'aawp_products_api_usage_count', 0 );
		$usage_limit      = (int) get_option( 'aawp_products_api_usage_limit' );
		$free_usage_limit = (int) get_option( 'aawp_products_api_usage_free_limit', 150 );
		$additional_quota = max( 0, $usage_limit - $free_usage_limit );

		$total_limit = $free_usage_limit + $additional_quota;

		$usage_percent  = $total_limit > 0 ? round( ( $usage_count / $total_limit ) * 100 ) : 0;
		$progress_class = '';

		if ( $usage_percent >= 90 ) {
			$progress_class = 'aawp-api-progress-red';
		} elseif ( $usage_percent >= 80 ) {
			$progress_class = 'aawp-api-progress-orange';
		} else {
			$progress_class = 'aawp-api-progress-green';
		}

		?>
		<div class="aawp-api-usage-card">
			<!-- Title -->
			<strong class="aawp-api-usage-title">
				<?php printf( esc_html__( 'Quota Usage (%s)', 'aawp' ), date_i18n( 'F' ) ); ?>
				<button 
					name="aawp_aawp_api[usage_quota]" 
					value="1" 
					class="aawp-api-usage-refresh-btn"
				>
					<span class="dashicons dashicons-update"></span>
					<span class="aawp-refresh-text"><?php esc_html_e( 'Click to refresh', 'aawp' ); ?></span>
				</button>
			</strong>

			<!-- Progress bar -->
			<div class="aawp-api-progress-bar">
				<div class="aawp-api-progress-fill <?php echo esc_attr( $progress_class ); ?>" style="width:<?php echo esc_attr( $usage_percent ); ?>%;"></div>
			</div>

			<small class="aawp-api-usage-count">
				<?php
					printf(
						/* translators: 1: used products, 2: total products, 3: remaining products */
						wp_kses_post( __( '<strong>%1$s of %2$s products fetched this month (%3$s remaining)</strong>', 'aawp' ) ),
						$usage_count,
						$total_limit,
						max( $total_limit - $usage_count, 0 )
					);
				?>
			</small>

			<!-- Quota breakdown -->
			<div class="aawp-api-quota-breakdown">
				<?php
					printf(
						esc_html__( 'Free quota: %1$s | Additional quota: %2$s | Total: %3$s', 'aawp' ),
						$free_usage_limit,
						$additional_quota,
						$total_limit
					);
				?>
			</div>

			<!-- Reset info -->
			<div class="aawp-api-reset-info">
				<?php
					/* translators: %1$s = next month name, %2$d = day of reset , $3$d = year*/
					printf(
						esc_html__( 'Resets: %1$s %2$d, %3$d', 'aawp' ),
						date_i18n( 'F', strtotime( 'first day of next month' ) ),
						1,
						date_i18n( 'Y', strtotime( 'first day of next month' ) )
					);
				?>
			</div>

			<!-- Conditional CTA -->
			<?php if ( $additional_quota > 0 || $free_usage_limit > 0 ) : ?>
				<div class="message info aawp-api-cta">
					<?php if ( $additional_quota > 0 ) : ?>
						<?php
							printf(
								/* translators: %s = purchase link */
								wp_kses_post(
									__( 'Need more? %s to increase your monthly limit.', 'aawp' )
								),
								'<a href="' . esc_url( aawp_get_page_url( 'feature:aawp-api' ) ) . '" class="aawp-api-cta-link" target="_blank" rel="nofollow noopener noreferrer">' .
									esc_html__( 'Purchase additional quota', 'aawp' ) .
								'</a>'
							);
						?>
					<?php else : ?>
						<?php
							printf(
								/* translators: 1: free limit, 2: upgrade link */
								esc_html__( '%s for more.', 'aawp' ),
								'<a href="' . esc_url( aawp_get_page_url( 'feature:aawp-api' ) ) . '" class="aawp-api-cta-link" target="_blank" rel="nofollow noopener noreferrer">' .
									esc_html__( 'Upgrade anytime', 'aawp' ) .
								'</a>'
							);
						?>
					<?php endif; ?>
				</div>
			<?php endif; ?>
		</div>
		<?php
	}

	/**
	 * Render the country dropdown for AAWP API.
	 *
	 * @since 4.2.0
	 */
	public function settings_aawp_api_country_render() {

		$country_tags = aawp_get_amazon_stores();

		$country = ( isset( $this->options['aawp_api']['country'] ) ) ? esc_attr( $this->options['aawp_api']['country'] ) : 'de';

		ksort( $country_tags );
		?>
		<select id="aawp_api_country" name="aawp_aawp_api[country]" data-aawp-api-country-selector="true" 
		<?php
		if ( ! aawp_is_user_admin() ) {
			echo 'readonly';}
		?>
		>
			<?php foreach ( $country_tags as $tag => $label ) { ?>
				<option value="<?php echo $tag; ?>" <?php selected( $country, $tag ); ?>>amazon.<?php echo $tag; ?></option>
			<?php } ?>
		</select>
		<span id="aawp_api_country_icon" data-aawp-api-country-preview="true"><?php aawp_the_icon_flag( $country ); ?></span>
		<?php
	}

	/**
	 * Render the Tracking ID input for AAWP API.
	 *
	 * @since 4.2.0
	 */
	public function settings_aawp_api_associate_tag_render() {

		$associate_tag = ( isset( $this->options['aawp_api']['associate_tag'] ) ) ? esc_attr( $this->options['aawp_api']['associate_tag'] ) : '';

		?>
		<input type="text" id="aawp_api_associate_tag" class="regular-text" name="aawp_aawp_api[associate_tag]" value="<?php echo $associate_tag; ?>" 
																															<?php
																															if ( ! aawp_is_user_admin() ) {
																																echo 'readonly';}
																															?>
		/>
		<p class="description">
			<small><?php _e( 'Without the tracking id, conversions cannot be assigned to your affiliate account.', 'aawp' ); ?><br /><?php _e( 'Your tracking id should look similar to this: <strong>aawp-21</strong> (might differ depending on the country).', 'aawp' ); ?></small>
		</p>
		<p>
		<?php
		printf(
					/* translators: %s - geotargeting tab link and text. */
			esc_html__( 'Do you want to promote more than one Amazon Associates Program at the same time? Simply %s.', 'aawp' ),
			'<a href="' . admin_url( 'admin.php?page=aawp-settings&tab=geotargeting' ) . '">' . esc_html__( 'configure geotargeting' ) . '</a>'
		);
		?>
			</p>
		<?php
	}
}