<?php

namespace AAWP\Admin\ProductsTable;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

/**
 * Core class for Products.
 *
 * @since 3.19
 */
class Init {

	/**
	 * Instance of the Products ListTable.
	 *
	 * Used to display the products table and handle bulk/single actions.
	 *
	 * @since 4.3.0
	 *
	 * @var \AAWP\Admin\ProductsTable\ListTable
	 */
	private ListTable $products_table;

	/**
	 * Initialize.
	 *
	 * @since 3.19
	 */
	public function init() {

		add_action( 'aawp_admin_menu', [ $this, 'add_products_submenu' ], 20 );
		add_action( 'admin_init', [ $this, 'maybe_process_products_actions' ] );
	}

	/**
	 * The products submenu under AAWP Menu.
	 *
	 * @param string $menu_slug AAWP Menu Slug (aawp).
	 *
	 * @since 3.19
	 */
	public function add_products_submenu( $menu_slug ) {

		add_submenu_page(
			$menu_slug,
			esc_html__( 'AAWP - Products', 'aawp' ),
			esc_html__( 'Products', 'aawp' ),
			'edit_pages',
			'aawp-products',
			[ $this, 'pages' ]
		);
	}

	/**
	 * Render Products.
	 *
	 * @since 3.19
	 */
	public function pages() {

		ob_start();
		?>
			<div class="wrap aawp-wrap">
				<h2>
					<?php esc_html_e( 'Products', 'aawp' ); ?>
				</h2>
			</div>
			<br/>
		<?php

		$heading = ob_get_clean();

		echo $heading; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped

		if ( ! isset( $this->products_table ) ) {
			$this->products_table = new ListTable();
		}

		$this->products_table->display_page();
	}

	/**
	 * Process actions before page output.
	 *
	 * @since 3.19
	 */
	public function maybe_process_products_actions() {

		if ( ! isset( $_GET['page'] ) || 'aawp-products' !== $_GET['page'] ) {
			return;
		}

		if ( ! isset( $this->products_table ) ) {
			$this->products_table = new ListTable();
		}

		$this->products_table->process_actions();
	}
}
