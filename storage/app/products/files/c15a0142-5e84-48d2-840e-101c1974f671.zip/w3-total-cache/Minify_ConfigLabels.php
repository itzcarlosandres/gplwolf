<?php
/**
 * File: Minify_ConfigLabels.php
 *
 * @package W3TC
 */

namespace W3TC;

/**
 * Class Minify_ConfigLabels
 *
 * phpcs:disable WordPress.Arrays.MultipleStatementAlignment.DoubleArrowNotAligned
 * phpcs:disable WordPress.Arrays.MultipleStatementAlignment.LongIndexSpaceBeforeDoubleArrow
 */
class Minify_ConfigLabels {
	/**
	 * Merges additional configuration labels for the Minify module.
	 *
	 * @param array $config_labels Existing configuration labels.
	 *
	 * @return array Merged configuration labels including Minify-specific options.
	 */
	public function config_labels( $config_labels ) {
		return array_merge(
			$config_labels,
			array(
				'minify.engine'                                        => __( 'Minify Cache Method:', 'w3-total-cache' ),
				'minify.enabled'                                       => __( 'Minify:', 'w3-total-cache' ),
				'minify.debug'                                         => __( 'Minify', 'w3-total-cache' ),
				'minify.html.engine'                                   => wp_kses(
					sprintf(
						// translators: 1: opening acronym tag for HTML, 2: closing acronym tag.
						__(
							'%1$sHTML%2$s minifier:',
							'w3-total-cache'
						),
						'<acronym title="' . esc_attr__( 'Hypertext Markup Language', 'w3-total-cache' ) . '">',
						'</acronym>'
					),
					array(
						'acronym' => array(
							'title' => array(),
						),
					)
				),
				'minify.js.engine'                                     => wp_kses(
					sprintf(
						// translators: 1: opening acronym tag for JS, 2: closing acronym tag.
						__(
							'%1$sJS%2$s minifier:',
							'w3-total-cache'
						),
						'<acronym title="' . esc_attr__( 'JavaScript', 'w3-total-cache' ) . '">',
						'</acronym>'
					),
					array(
						'acronym' => array(
							'title' => array(),
						),
					)
				),
				'minify.css.engine'                                    => wp_kses(
					sprintf(
						// translators: 1: opening acronym tag for CSS, 2: closing acronym tag.
						__(
							'%1$sCSS%2$s minifier:',
							'w3-total-cache'
						),
						'<acronym title="' . esc_attr__( 'Cascading Style Sheets', 'w3-total-cache' ) . '">',
						'</acronym>'
					),
					array(
						'acronym' => array(
							'title' => array(),
						),
					)
				),
				'minify.auto'                                          => __( 'Minify mode:', 'w3-total-cache' ),
				'minify.rewrite'                                       => wp_kses(
					sprintf(
						// translators: 1: opening acronym tag for URL, 2: closing acronym tag.
						__(
							'Rewrite %1$sURL%2$s structure',
							'w3-total-cache'
						),
						'<acronym title="' . esc_attr__( 'Uniform Resource Locator', 'w3-total-cache' ) . '">',
						'</acronym>'
					),
					array(
						'acronym' => array(
							'title' => array(),
						),
					)
				),
				'minify.reject.logged'                                 => __( 'Disable minify for logged in users', 'w3-total-cache' ),
				'minify.error.notification'                            => __( 'Minify error notification:', 'w3-total-cache' ),
				'minify.html.enable'                                   => __( 'Enable', 'w3-total-cache' ),
				'minify.html.inline.css'                               => wp_kses(
					sprintf(
						// translators: 1: opening acronym tag for CSS, 2: closing acronym tag.
						__(
							'Inline %1$sCSS%2$s minification',
							'w3-total-cache'
						),
						'<acronym title="' . esc_attr__( 'Cascading Style Sheets', 'w3-total-cache' ) . '">',
						'</acronym>'
					),
					array(
						'acronym' => array(
							'title' => array(),
						),
					)
				),
				'minify.html.inline.js'                                => wp_kses(
					sprintf(
						// translators: 1: opening acronym tag for JS, 2: closing acronym tag.
						__(
							'Inline %1$sJS%2$s minification',
							'w3-total-cache'
						),
						'<acronym title="' . esc_attr__( 'JavaScript', 'w3-total-cache' ) . '">',
						'</acronym>'
					),
					array(
						'acronym' => array(
							'title' => array(),
						),
					)
				),
				'minify.html.reject.feed'                              => __( 'Don\'t minify feeds', 'w3-total-cache' ),
				'minify.html.comments.ignore'                          => __( 'Ignored comment stems:', 'w3-total-cache' ),
				'minify.js.enable'                                     => __( 'Enable', 'w3-total-cache' ),
				'minify.js.method'                                     => __( 'Minify method:', 'w3-total-cache' ),
				'minify.js.header.embed_type'                          => __( 'Embed type:', 'w3-total-cache' ),
				'minify.js.combine.header'                             => __( 'Combine only', 'w3-total-cache' ),
				'minify.js.body.embed_type'                            => wp_kses(
					sprintf(
						// translators: 1: span tag for <body>.
						__(
							'After %1$s',
							'w3-total-cache'
						),
						'<span class="html-tag">&lt;body&gt;</span>'
					),
					array(
						'span' => array(
							'class' => array(),
						),
					)
				),
				'minify.js.combine.body'                               => __( 'Combine only', 'w3-total-cache' ),
				'minify.js.footer.embed_type'                          => wp_kses(
					sprintf(
						// translators: 1: span tag for </body>.
						__(
							'Before %1$s',
							'w3-total-cache'
						),
						'<span class="html-tag">&lt;/body&gt;</span>'
					),
					array(
						'span' => array(
							'class' => array(),
						),
					)
				),
				'minify.js.combine.footer'                             => __( 'Combine only', 'w3-total-cache' ),
				'minify.js.http2push'                                  => wp_kses(
					sprintf(
						// translators: 1: opening acronym tag for HTTP, 2: closing acronym tag.
						__(
							'%1$sHTTP%2$s/2 push',
							'w3-total-cache'
						),
						'<acronym title="' . esc_attr__( 'Hypertext Transfer Protocol', 'w3-total-cache' ) . '">',
						'</acronym>'
					),
					array(
						'acronym' => array(
							'title' => array(),
						),
					)
				),
				'minify.css.enable'                                    => __( 'Enable', 'w3-total-cache' ),
				'minify.css.method'                                    => __( 'Minify method:', 'w3-total-cache' ),
				'minify.css.imports'                                   => __( '@import handling:', 'w3-total-cache' ),
				'minify.css.http2push'                                 => wp_kses(
					sprintf(
						// translators: 1: opening acronym tag for HTTP, 2: closing acronym tag.
						__(
							'%1$sHTTP%2$s/2 push',
							'w3-total-cache'
						),
						'<acronym title="' . esc_attr__( 'Hypertext Transfer Protocol', 'w3-total-cache' ) . '">',
						'</acronym>'
					),
					array(
						'acronym' => array(
							'title' => array(),
						),
					)
				),
				'minify.lifetime'                                      => __( 'Update external files every:', 'w3-total-cache' ),
				'minify.file.gc'                                       => __( 'Garbage collection interval:', 'w3-total-cache' ),
				'minify.reject.uri'                                    => __( 'Never minify the following pages:', 'w3-total-cache' ),
				'minify.reject.files.js'                               => wp_kses(
					sprintf(
						// translators: 1: opening acronym tag for JS, 2: closing acronym tag.
						__(
							'Never minify the following %1$sJS%2$s files:',
							'w3-total-cache'
						),
						'<acronym title="' . esc_attr__( 'JavaScript', 'w3-total-cache' ) . '">',
						'</acronym>'
					),
					array(
						'acronym' => array(
							'title' => array(),
						),
					)
				),
				'minify.reject.files.css'                              => wp_kses(
					sprintf(
						// translators: 1: opening acronym tag for CSS, 2: closing acronym tag.
						__(
							'Never minify the following %1$sCSS%2$s files:',
							'w3-total-cache'
						),
						'<acronym title="' . esc_attr__( 'Cascading Style Sheets', 'w3-total-cache' ) . '">',
						'</acronym>'
					),
					array(
						'acronym' => array(
							'title' => array(),
						),
					)
				),
				'minify.reject.ua'                                     => __( 'Rejected user agents:', 'w3-total-cache' ),
				'minify.cache.files'                                   => __( 'Include external files/libraries:', 'w3-total-cache' ),
				'minify.cache.files_regexp'                            => __( 'Use regular expressions for file name matching', 'w3-total-cache' ),
				'minify.wp_cron'                                       => __( 'Enable WP-Cron Event', 'w3-total-cache' ),
				'minify.wp_cron_time'                                  => __( 'Start Time', 'w3-total-cache' ),
				'minify.wp_cron_interval'                              => __( 'Interval', 'w3-total-cache' ),
				// options->minify->ccjs.
				'minify.ccjs.options.formatting'                       => __( 'Pretty print', 'w3-total-cache' ),
				// options->minify->ccjs2.
				'minify.ccjs.path.java'                                => __( 'Path to JAVA executable:', 'w3-total-cache' ),
				'minify.ccjs.path.jar'                                 => __( 'Path to JAR file:', 'w3-total-cache' ),
				'minify.ccjs.options.compilation_level'                => __( 'Compilation level:', 'w3-total-cache' ),
				// options->minify->css.
				'minify.css.strip.comments'                            => __( 'Preserved comment removal (not applied when combine only is active)', 'w3-total-cache' ),
				'minify.css.strip.crlf'                                => __( 'Line break removal (not applied when combine only is active)', 'w3-total-cache' ),
				// options->minify->csstidy.
				'minify.csstidy.options.remove_bslash'                 => __( 'Remove unnecessary backslashes', 'w3-total-cache' ),
				'minify.csstidy.options.compress_colors'               => __( 'Compress colors', 'w3-total-cache' ),
				'minify.csstidy.options.compress_font-weight'          => __( 'Compress font-weight', 'w3-total-cache' ),
				'minify.csstidy.options.lowercase_s'                   => __( 'Lowercase selectors', 'w3-total-cache' ),
				'minify.csstidy.options.remove_last_;'                 => __( 'Remove last ;', 'w3-total-cache' ),
				'minify.csstidy.options.remove_space_before_important' => __( 'Remove space before !important', 'w3-total-cache' ),
				'minify.csstidy.options.sort_properties'               => __( 'Sort Properties', 'w3-total-cache' ),
				'minify.csstidy.options.sort_selectors'                => __( 'Sort Selectors (caution)', 'w3-total-cache' ),
				'minify.csstidy.options.discard_invalid_selectors'     => __( 'Discard invalid selectors', 'w3-total-cache' ),
				'minify.csstidy.options.discard_invalid_properties'    => __( 'Discard invalid properties', 'w3-total-cache' ),
				'minify.csstidy.options.preserve_css'                  => __( 'Preserve CSS', 'w3-total-cache' ),
				'minify.csstidy.options.timestamp'                     => __( 'Add timestamp', 'w3-total-cache' ),
				// options->minify->csstidy2.
				'minify.csstidy.options.template'                      => __( 'Compression:', 'w3-total-cache' ),
				'minify.csstidy.options.optimise_shorthands'           => __( 'Optimize shorthands:', 'w3-total-cache' ),
				'minify.csstidy.options.case_properties'               => __( 'Case for properties:', 'w3-total-cache' ),
				'minify.csstidy.options.merge_selectors'               => __( 'Regroup selectors:', 'w3-total-cache' ),
				// options->minify->html.
				'minify.html.strip.crlf'                               => __( 'Line break removal', 'w3-total-cache' ),
				// options->minify_>htmltidy.
				'minify.htmltidy.options.clean'                        => __( 'Clean', 'w3-total-cache' ),
				'minify.htmltidy.options.hide-comments'                => __( 'Hide comments', 'w3-total-cache' ),
				// options->minify->htmltidy2.
				'minify.htmltidy.options.wrap'                         => __( 'Wrap after:', 'w3-total-cache' ),
				// options->minify->js.
				'minify.js.strip.comments'                             => __( 'Preserved comment removal (not applied when combine only is active)', 'w3-total-cache' ),
				'minify.js.strip.crlf'                                 => __( 'Line break removal (not safe, not applied when combine only is active)', 'w3-total-cache' ),
				// options->minify->yuicss2.
				'minify.yuicss.path.java'                              => __( 'Path to JAVA executable:', 'w3-total-cache' ),
				'minify.yuicss.path.jar'                               => __( 'Path to JAR file:', 'w3-total-cache' ),
				'minify.yuicss.options.line-break'                     => __( 'Line break after:', 'w3-total-cache' ),
				// options->minify->yuijs.
				'minify.yuijs.options.nomunge'                         => __( 'Minify only, do not obfuscate local symbols', 'w3-total-cache' ),
				'minify.yuijs.options.preserve-semi'                   => __( 'Preserve unnecessary semicolons', 'w3-total-cache' ),
				'minify.yuijs.options.disable-optimizations'           => __( 'Disable all the built-in micro optimizations', 'w3-total-cache' ),
				'minify.yuijs.options.line-break'                      => __( 'Line break after:', 'w3-total-cache' ),
			)
		);
	}
}
