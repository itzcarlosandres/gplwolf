<?php

/**
 * Plugin Name: Winden
 * Plugin URI:  https://dplugins.com/
 * Description: Universal Tailwind CSS integration for WordPress Page Builders.
 * Version: 2.9.5
 * Author: DPlugins
 * Author URI: https://dplugins.com/
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Requires at least: 6.2
 * Tested up to: 6.9
 * Requires PHP: 7.4
 * Text Domain: winden
 */

defined('ABSPATH') or die('Move Along, Nothing to See Here');

// Extract version from plugin header
$plugin_data = get_file_data(__FILE__, ['Version' => 'Version']);

// Plugin constants
define('WINDTACS_VERSION', $plugin_data['Version']);
define('WINDTACS_WEBSITE_URL', get_site_url());
define('WINDTACS_UPLOADS_URL', wp_upload_dir());
define('WINDTACS_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('WINDTACS_PLUGIN_URL', plugin_dir_url(__FILE__));
define('WINDTACS_ASSETS_DIR', plugin_dir_url(__FILE__) . 'assets/');

// Include the Composer autoload
require __DIR__ . '/vendor/autoload.php';

use Winden\App\App;

new App();
