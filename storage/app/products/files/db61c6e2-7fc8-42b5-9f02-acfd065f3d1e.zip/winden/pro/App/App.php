<?php

namespace Winden\Pro;

use Winden\Pro\Config;
use Winden\Pro\Updater;
use Winden\App\Helpers\LicenseManager;

/**
 * Pro App Entry Point
 *
 * This class initializes all Pro features when the /pro/ folder exists
 */
class App
{
	public function __construct()
	{
		$this->initEDD();
		$this->initAdmin();
	}

	/**
	 * Initialize EDD configuration and updater
	 */
	private function initEDD()
	{
		if (file_exists(WINDTACS_PLUGIN_DIR . 'pro/App/Config.php')) {
			require_once WINDTACS_PLUGIN_DIR . 'pro/App/Config.php';
			require_once WINDTACS_PLUGIN_DIR . 'pro/App/Updater.php';

			Config::define_constants();
			Updater::init();
		}
	}

	/**
	 * Initialize Pro admin features
	 */
	private function initAdmin()
	{
		new \Winden\Pro\Admin\License();
		new \Winden\Pro\Admin\Release();

		// Only load FileBrowser if license is active
		if (LicenseManager::isProActive()) {
			new \Winden\Pro\Admin\FileBrowser();
		}
	}
}
