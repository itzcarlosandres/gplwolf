<?php

namespace Winden\Pro;

defined('ABSPATH') or die('Move Along, Nothing to See Here');

/**
 * EDD Plugin Updater
 */
class Updater
{
	/**
	 * Initialize the updater
	 */
	public static function init()
	{
		// Load EDD Updater class
		if (!class_exists('Winden_SL_Plugin_Updater')) {
			include(WINDTACS_PLUGIN_DIR . 'pro/App/EDD/PluginUpdater.php');
		}

		// Hook into WordPress init
		add_action('init', [__CLASS__, 'plugin_updater']);
	}

	/**
	 * EDD Plugin Updater function
	 */
	public static function plugin_updater()
	{
		// To support auto-updates, this needs to run during the wp_version_check cron job for privileged users.
		$doing_cron = defined('DOING_CRON') && DOING_CRON;
		if (!current_user_can('manage_options') && !$doing_cron) {
			return;
		}

		// Retrieve license key from the winden_license option (stores array with key, status, checkedAt)
		$license_data = get_option('winden_license', []);
		$license_key = isset($license_data['key']) ? trim($license_data['key']) : '';

		// setup the updater
		$edd_updater = new \Winden_SL_Plugin_Updater(
			WINDTACS_STORE_URL,
			WINDTACS_UPDATER,
			array(
				'version' => WINDTACS_VERSION,                // current version number
				'license' => $license_key,                  // license key (used get_option above to retrieve from DB)
				'item_id' => WINDTACS_ITEM_ID,               // ID of the product
				'author'  => WINDTACS_AUTHOR,                // author of this plugin
				'beta'    => false,
			)
		);
	}
}
