<?php

namespace Winden\Pro;

defined('ABSPATH') or die('Move Along, Nothing to See Here');

/**
 * EDD Store Configuration
 */
class Config
{
	/**
	 * Define EDD constants
	 */
	public static function define_constants()
	{
		// EDD Store Configuration
		define('WINDTACS_STORE_URL', 'https://dplugins.com/');
		define('WINDTACS_ITEM_ID', 46608); // Winden product ID from dplugins.com
		define('WINDTACS_ITEM_NAME', 'Winden');
		define('WINDTACS_ADMIN_SLUG', 'winden');
		define('WINDTACS_AUTHOR', 'devusrmk');

		// Plugin file paths (WINDTACS_VERSION already defined in winden.php)
		$plugin_file = WINDTACS_PLUGIN_DIR . 'winden.php';
		define('WINDTACS_UPDATER', $plugin_file);
		define('WINDTACS_BASE', plugin_basename($plugin_file));
	}
}
