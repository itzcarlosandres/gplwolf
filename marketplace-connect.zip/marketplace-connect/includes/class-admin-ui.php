<?php

class Marketplace_Admin_UI {
    private $plugin_name;
    private $version;
    private $api;

    public function __construct( $plugin_name, $version, $api ) {
        $this->plugin_name = $plugin_name;
        $this->version = $version;
        $this->api = $api;
    }

    public function add_plugin_admin_menu() {
        add_menu_page(
            'Marketplace Connect', 
            'Marketplace', 
            'manage_options', 
            $this->plugin_name, 
            array( $this, 'display_plugin_dashboard' ), 
            'dashicons-cart', 
            6
        );

        add_submenu_page(
            $this->plugin_name,
            'Ajustes',
            'Ajustes',
            'manage_options',
            'marketplace-connect-settings',
            array($this, 'display_settings_page')
        );
    }

    public function enqueue_styles() {
        wp_enqueue_style( 'mp-admin-css', MARKETPLACE_CONNECT_PLUGIN_URL . 'assets/css/admin.css', array(), $this->version, 'all' );
        // Usar Tailwind CDN para prototipado rápido o estilos propios
        wp_enqueue_style( 'mp-tailwind', 'https://cdn.tailwindcss.com' ); 
    }

    public function enqueue_scripts() {
        wp_enqueue_script( 'mp-admin-js', MARKETPLACE_CONNECT_PLUGIN_URL . 'assets/js/admin.js', array( 'jquery' ), $this->version, false );
        wp_localize_script( 'mp-admin-js', 'mp_ajax', array( 'ajax_url' => admin_url( 'admin-ajax.php' ) ) );
    }

    public function display_plugin_dashboard() {
        $token = get_option('mp_api_token');
        if (!$token) {
            $this->display_login_form();
        } else {
            $this->display_products_grid();
        }
    }

    public function display_login_form() {
        ?>
        <div class="wrap mp-login-container" style="max-width: 400px; margin: 50px auto; padding: 30px; background: #fff; border-radius: 10px; box-shadow: 0 10px 25px rgba(0,0,0,0.05);">
            <h1 style="text-align: center; margin-bottom: 20px;">Conectar con Marketplace</h1>
            <div id="mp-login-message"></div>
            <form id="mp-login-form">
                <div style="margin-bottom: 15px;">
                    <label style="display: block; font-weight: bold; margin-bottom: 5px;">Email</label>
                    <input type="email" name="email" class="widefat" required>
                </div>
                <div style="margin-bottom: 20px;">
                    <label style="display: block; font-weight: bold; margin-bottom: 5px;">Contraseña</label>
                    <input type="password" name="password" class="widefat" required>
                </div>
                <button type="submit" class="button button-primary button-hero" style="width: 100%;">Conectar Sitio</button>
            </form>
        </div>
        <script>
        jQuery(document).ready(function($) {
            $('#mp-login-form').on('submit', function(e) {
                e.preventDefault();
                var data = {
                    action: 'mp_connect_login',
                    email: $('input[name="email"]').val(),
                    password: $('input[name="password"]').val()
                };
                
                $('#mp-login-message').html('<p style="color: blue;">Conectando...</p>');
                
                $.post(mp_ajax.ajax_url, data, function(response) {
                    if(response.success) {
                        location.reload();
                    } else {
                        $('#mp-login-message').html('<p style="color: red;">' + response.data + '</p>');
                    }
                });
            });
        });
        </script>
        <?php
    }

    public function display_products_grid() {
        // Refresh User Info to get latest points/limits
        $this->api->refresh_user_info();
        $user_info = get_option('mp_user_info');
        
        // Fetch products page 1
        $products_data = $this->api->get_products();
        $products = $products_data['data'] ?? [];
        
        // Obtener plugins instalados para comparar versiones
        if ( ! function_exists( 'get_plugins' ) ) {
            require_once ABSPATH . 'wp-admin/includes/plugin.php';
        }
        $installed_plugins = get_plugins();
        ?>
        <div class="wrap mp-wrapper">
            <!-- Header Grid -->
            <div class="mp-header-grid">
                <!-- Title & Profile -->
                <div class="mp-welcome-card">
                    <div class="mp-user-profile-lg">
                        <div class="mp-avatar-lg">
                            <?php echo strtoupper(substr($user_info['name'], 0, 1)); ?>
                        </div>
                        <div>
                            <h1 class="mp-welcome-title">Hola, <?php echo esc_html($user_info['name']); ?></h1>
                            <p class="mp-welcome-sub">Explora recursos premium para tu sitio.</p>
                        </div>
                    </div>
                </div>

                <!-- Stats: Points -->
                <div class="mp-stat-card">
                    <div class="mp-stat-icon mp-icon-points">
                        <span class="dashicons dashicons-awards"></span>
                    </div>
                    <div>
                        <span class="mp-stat-label">Mis Puntos</span>
                        <span class="mp-stat-value"><?php echo number_format($user_info['points'] ?? 0); ?> Pts</span>
                    </div>
                </div>

                <!-- Stats: Downloads -->
                <div class="mp-stat-card">
                    <div class="mp-stat-icon mp-icon-downloads">
                        <span class="dashicons dashicons-download"></span>
                    </div>
                    <div style="flex: 1;">
                        <span class="mp-stat-label">Descargas Hoy</span>
                        <div class="mp-stat-row">
                            <span class="mp-stat-value">
                                <?php echo ($user_info['downloads_today'] ?? 0); ?> / <?php echo ($user_info['downloads_limit'] ?? 0); ?>
                            </span>
                        </div>
                        <?php 
                            $dl_today = intval($user_info['downloads_today'] ?? 0);
                            $dl_limit = intval($user_info['downloads_limit'] ?? 1); // Avoid div by zero
                            $percent = ($dl_limit > 0) ? min(100, ($dl_today / $dl_limit) * 100) : 0;
                            if($user_info['downloads_limit'] === 'Ilimitado') $percent = 0;
                        ?>
                        <div class="mp-progress-bar">
                            <div class="mp-progress-fill" style="width: <?php echo $percent; ?>%"></div>
                        </div>
                    </div>
                </div>

                <!-- Stats: Membership -->
                <div class="mp-stat-card">
                    <div class="mp-stat-icon mp-icon-plan">
                        <span class="dashicons dashicons-money-alt"></span>
                    </div>
                    <div style="flex: 1; display: flex; justify-content: space-between; align-items: center;">
                        <div>
                            <span class="mp-stat-label">Membresía</span>
                            <span class="mp-stat-value"><?php echo esc_html($user_info['plan'] ?? 'Gratis'); ?></span>
                        </div>
                         <button id="mp-disconnect-btn" class="mp-btn-text" title="Cerrar Sesión">
                            <span class="dashicons dashicons-migrate"></span> Salir
                        </button>
                    </div>
                </div>
            </div>

            <!-- Grid -->
            <div class="mp-grid">
                <?php if (empty($products)): ?>
                    <div class="mp-empty-state">
                        <span class="dashicons dashicons-warning"></span>
                        <p>No se encontraron productos disponibles para tu cuenta.</p>
                    </div>
                <?php else: ?>
                    <?php foreach ($products as $product): ?>
                        <?php 
                            $status = 'not_installed';
                            $installed_version = '';
                            
                            // Normalizar para slug (ej: "Elementor Pro" -> "elementor-pro")
                            $product_slug = sanitize_title($product['name']); 

                            foreach ($installed_plugins as $file => $p) {
                                // 1. Match por Nombre (Similar text)
                                // Usamos mb_stripos para case-insensitive y UTF-8
                                $name_match = (mb_stripos($p['Name'], $product['name']) !== false || mb_stripos($product['name'], $p['Name']) !== false);
                                
                                // 2. Match por Carpeta vs Slug (MEJORADO)
                                $plugin_folder = dirname($file);
                                if ($plugin_folder === '.') $plugin_folder = basename($file, '.php');
                                
                                // Normalizar ambos slugs para comparación
                                $plugin_folder_clean = strtolower($plugin_folder);
                                $product_slug_clean = strtolower($product_slug);
                                
                                // Match si cualquiera contiene al otro (más flexible)
                                $slug_match = (
                                    strpos($plugin_folder_clean, $product_slug_clean) !== false || 
                                    strpos($product_slug_clean, $plugin_folder_clean) !== false ||
                                    // También intentar sin guiones
                                    strpos(str_replace('-', '', $plugin_folder_clean), str_replace('-', '', $product_slug_clean)) !== false
                                );
                                
                                // 3. Match Agresivo (Solo letras y números)
                                $name_remoto_clean = preg_replace('/[^a-z0-9]/', '', strtolower(html_entity_decode($product['name'])));
                                $name_local_clean = preg_replace('/[^a-z0-9]/', '', strtolower(html_entity_decode($p['Name'])));

                                $fuzzy_match = (strpos($name_local_clean, $name_remoto_clean) !== false || strpos($name_remoto_clean, $name_local_clean) !== false);

                                // DEBUG: ACTIVADO - Ver comparaciones en consola del navegador
                                if (strpos(strtolower($product['name']), 'rank math') !== false || strpos(strtolower($p['Name']), 'rank math') !== false) {
                                    echo "<!-- DEBUG RANK MATH:\n";
                                    echo "Producto DB: '{$product['name']}' (v{$product['version']})\n";
                                    echo "Plugin Local: '{$p['Name']}' (v{$p['Version']})\n";
                                    echo "Product Slug: '{$product_slug}' | Plugin Folder: '{$plugin_folder}'\n";
                                    echo "Name Match: " . ($name_match ? 'SI' : 'NO') . "\n";
                                    echo "Slug Match: " . ($slug_match ? 'SI' : 'NO') . "\n";
                                    echo "Fuzzy Match: " . ($fuzzy_match ? 'SI' : 'NO') . "\n";
                                    echo "Remoto Clean: '{$name_remoto_clean}' | Local Clean: '{$name_local_clean}'\n";
                                    echo "-->\n";
                                }

                                if ($slug_match || $name_match || $fuzzy_match) {
                                    $installed_version = $p['Version'];
                                    
                                    if (version_compare($product['version'], $installed_version, '>')) {
                                        $status = 'update_available';
                                    } else {
                                        $status = 'installed';
                                    }
                                    break;
                                }
                            }
                        ?>
                        <div class="mp-card <?php echo $status; ?>">
                            <div class="mp-card-media">
                                <?php if($product['thumbnail']): ?>
                                    <img src="<?php echo esc_url($product['thumbnail']); ?>" alt="<?php echo esc_attr($product['name']); ?>">
                                <?php else: ?>
                                    <div class="mp-no-icon">
                                        <span class="dashicons dashicons-format-image"></span>
                                    </div>
                                <?php endif; ?>
                                
                                <div class="mp-card-badges">
                                    <?php if ($status === 'update_available'): ?>
                                        <span class="mp-badge mp-badge-update">Update v<?php echo esc_html($product['version']); ?></span>
                                    <?php elseif ($status === 'installed'): ?>
                                        <span class="mp-badge mp-badge-check">Instalado</span>
                                    <?php else: ?>
                                        <span class="mp-badge mp-badge-new">Nuevo</span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="mp-card-content">
                                <div class="mp-card-header">
                                    <h3 title="<?php echo esc_attr($product['name']); ?>"><?php echo esc_html($product['name']); ?></h3>
                                    <span class="mp-version">v<?php echo esc_html($product['version']); ?></span>
                                </div>
                                <p class="mp-description"><?php echo esc_html(mb_strimwidth($product['short_description'], 0, 70, '...')); ?></p>
                                
                                <div class="mp-actions">
                                    <?php if($product['can_download']): ?>
                                        <button class="mp-button <?php echo $status === 'update_available' ? 'mp-btn-update' : 'mp-btn-primary'; ?> mp-download-btn" data-id="<?php echo $product['id']; ?>">
                                            <?php if ($status === 'update_available'): ?>
                                                <span class="dashicons dashicons-update"></span> Actualizar
                                            <?php elseif ($status === 'installed'): ?>
                                                <span class="dashicons dashicons-download"></span> Re-instalar
                                            <?php else: ?>
                                                <span class="dashicons dashicons-download"></span> Instalar
                                            <?php endif; ?>
                                        </button>
                                    <?php else: ?>
                                        <button class="mp-button mp-btn-locked" disabled>
                                            <span class="dashicons dashicons-lock"></span> Premium
                                        </button>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>

        <style>
            /* Reset & Base */
            .mp-wrapper {
                font-family: 'Inter', -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
                background: linear-gradient(135deg, #0f172a 0%, #020617 100%);
                min-height: calc(100vh - 32px);
                margin: -20px -20px 0 -22px; 
                padding: 40px;
                color: #e2e8f0;
                box-sizing: border-box;
            }
            .mp-wrapper * { box-sizing: border-box; }

            /* Header Grid */
            .mp-header-grid {
                display: grid;
                grid-template-columns: 2fr 1fr 1fr 1fr;
                gap: 20px;
                margin-bottom: 40px;
                align-items: stretch;
            }
            @media (max-width: 1200px) { .mp-header-grid { grid-template-columns: 1fr 1fr; } }
            @media (max-width: 768px) { .mp-header-grid { grid-template-columns: 1fr; } }

            .mp-welcome-card {
                background: linear-gradient(135deg, rgba(168, 85, 247, 0.1), rgba(236, 72, 153, 0.1));
                border: 1px solid rgba(168, 85, 247, 0.2);
                border-radius: 24px;
                padding: 25px;
                display: flex;
                align-items: center;
            }
            .mp-user-profile-lg { display: flex; align-items: center; gap: 20px; }
            .mp-avatar-lg {
                width: 56px; height: 56px;
                background: linear-gradient(135deg, #a855f7, #ec4899);
                border-radius: 18px;
                display: flex; align-items: center; justify-content: center;
                font-size: 24px; font-weight: 700; color: white; box-shadow: 0 10px 20px rgba(168, 85, 247, 0.3);
            }
            .mp-welcome-title { font-size: 20px; font-weight: 700; color: #fff; margin: 0; line-height: 1.2; }
            .mp-welcome-sub { margin: 5px 0 0 0; color: #94a3b8; font-size: 13px; }

            /* Stat Cards */
            .mp-stat-card {
                background: rgba(30, 41, 59, 0.5);
                border: 1px solid rgba(255,255,255,0.05);
                border-radius: 24px;
                padding: 20px;
                display: flex;
                align-items: center;
                gap: 15px;
                backdrop-filter: blur(10px);
                transition: transform 0.2s;
            }
            .mp-stat-card:hover { transform: translateY(-2px); background: rgba(30, 41, 59, 0.8); }
            
            .mp-stat-icon {
                width: 48px; height: 48px;
                border-radius: 14px;
                display: flex; align-items: center; justify-content: center;
                font-size: 20px;
            }
            .mp-icon-points { background: rgba(234, 179, 8, 0.1); color: #eab308; }
            .mp-icon-downloads { background: rgba(59, 130, 246, 0.1); color: #3b82f6; }
            .mp-icon-plan { background: rgba(168, 85, 247, 0.1); color: #a855f7; }

            .mp-stat-label { display: block; font-size: 11px; text-transform: uppercase; letter-spacing: 0.5px; color: #64748b; font-weight: 600; margin-bottom: 4px; }
            .mp-stat-value { font-size: 18px; font-weight: 700; color: #fff; }
            .mp-stat-row { display: flex; justify-content: space-between; align-items: flex-end; margin-bottom: 6px; }

            .mp-progress-bar { height: 4px; background: rgba(255,255,255,0.1); border-radius: 2px; overflow: hidden; width: 100%; margin-top: 5px; }
            .mp-progress-fill { height: 100%; background: #3b82f6; border-radius: 2px; }

            .mp-btn-text { background: none; border: none; color: #ef4444; font-size: 12px; font-weight: 600; cursor: pointer; display: flex; align-items: center; gap: 4px; padding: 0; }
            .mp-btn-text:hover { text-decoration: underline; }

            /* Grid */
            .mp-grid {
                display: grid;
                grid-template-columns: repeat(auto-fill, minmax(260px, 1fr));
                gap: 24px;
            }
            
            /* Card */
            .mp-card {
                background: rgba(30, 41, 59, 0.4);
                border: 1px solid rgba(255,255,255,0.05);
                border-radius: 20px;
                overflow: hidden;
                transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
                display: flex; flex-direction: column;
            }
            .mp-card:hover {
                transform: translateY(-5px);
                background: rgba(30, 41, 59, 1);
                border-color: rgba(168, 85, 247, 0.3);
                box-shadow: 0 20px 40px -10px rgba(0,0,0,0.5);
            }
            
            .mp-card.update_available { border-color: rgba(239, 68, 68, 0.4); }

            /* Media */
            .mp-card-media {
                height: 150px;
                position: relative;
                background: #0f172a;
                overflow: hidden;
            }
            .mp-card-media img {
                width: 100%; height: 100%; object-fit: cover;
                transition: transform 0.5s; opacity: 0.9;
            }
            .mp-card:hover .mp-card-media img { transform: scale(1.1); opacity: 1; }
            
            .mp-no-icon { width: 100%; height: 100%; display: flex; align-items: center; justify-content: center; color: #334155; }
            .mp-no-icon span { font-size: 48px; width: 48px; height: 48px; }

            /* Badges */
            .mp-card-badges {
                position: absolute; top: 10px; right: 10px;
                display: flex; flex-direction: column; gap: 5px; align-items: flex-end;
            }
            .mp-badge {
                padding: 4px 10px; border-radius: 8px;
                font-size: 10px; font-weight: 700; text-transform: uppercase;
                color: #fff; backdrop-filter: blur(8px);
                box-shadow: 0 4px 10px rgba(0,0,0,0.2);
            }
            .mp-badge-update { background: rgba(239, 68, 68, 0.9); }
            .mp-badge-check { background: rgba(34, 197, 94, 0.9); }
            .mp-badge-new { background: rgba(59, 130, 246, 0.9); }

            /* Content */
            .mp-card-content { padding: 18px; flex: 1; display: flex; flex-direction: column; }
            .mp-card-header { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 6px; }
            .mp-card-header h3 { margin: 0; font-size: 15px; font-weight: 700; color: #f1f5f9; line-height: 1.4; }
            .mp-version { font-size: 10px; color: #94a3b8; background: rgba(255,255,255,0.05); padding: 2px 6px; border-radius: 4px; }
            .mp-description { font-size: 12px; color: #64748b; line-height: 1.5; margin: 0 0 15px 0; flex: 1; }

            /* Actions */
            .mp-actions { margin-top: auto; }
            .mp-button {
                width: 100%; padding: 10px; border-radius: 12px; border: none;
                font-weight: 600; font-size: 13px; cursor: pointer;
                display: flex; align-items: center; justify-content: center; gap: 8px;
                transition: all 0.2s;
            }
            .mp-btn-primary { background: #3b82f6; color: white; }
            .mp-btn-primary:hover { background: #2563eb; transform: translateY(-1px); }
            
            .mp-btn-update { 
                background: linear-gradient(135deg, #ef4444, #f97316); 
                color: white; 
                box-shadow: 0 4px 12px rgba(239, 68, 68, 0.3);
            }
            .mp-btn-update:hover { filter: brightness(1.1); transform: translateY(-1px); }

            .mp-btn-locked { background: rgba(255,255,255,0.05); color: #475569; cursor: not-allowed; }
            
            .mp-empty-state { grid-column: 1 / -1; padding: 40px; text-align: center; color: #64748b; background: rgba(255,255,255,0.02); border-radius: 20px; border: 2px dashed rgba(255,255,255,0.05); }
            .mp-empty-state .dashicons { font-size: 40px; width: 40px; height: 40px; margin-bottom: 10px; display: block; margin: 0 auto; }
        </style>

        <script>
        jQuery(document).ready(function($) {
            // Logic remains similar, just classes updated
            $('#mp-disconnect-btn').click(function(e) {
                e.preventDefault();
                if(!confirm('¿Seguro que quieres desconectar?')) return;
                $.post(mp_ajax.ajax_url, { action: 'mp_disconnect' }, function() {
                    location.reload();
                });
            });

            $('.mp-download-btn').click(function(e) {
                e.preventDefault();
                var btn = $(this);
                var id = btn.data('id');
                var originalHtml = btn.html();
                
                btn.prop('disabled', true).addClass('processing').html('<span class="dashicons dashicons-update-alt"></span>');

                $.post(mp_ajax.ajax_url, { action: 'mp_download_item', id: id }, function(response) {
                    if(response.success) {
                        btn.html('<span class="dashicons dashicons-yes"></span>');
                        if(response.data.url) {
                            var link = document.createElement('a');
                            link.href = response.data.url;
                            link.setAttribute('download', '');
                            document.body.appendChild(link);
                            link.click();
                            document.body.removeChild(link);
                        }
                        setTimeout(function(){ 
                            btn.prop('disabled', false).removeClass('processing').html(originalHtml); 
                        }, 2000);
                    } else {
                        alert(response.data);
                        btn.prop('disabled', false).html(originalHtml);
                    }
                });
            });
        });
        </script>
        <?php
    }
    
    // Fallback image helper (optional CSS)
    public function custom_css() {
        // ...
    }

    public function display_settings_page() {
        echo '<div class="wrap"><h1>Ajustes de Marketplace Connect</h1><p>Versión: ' . $this->version . '</p></div>';
    }

    // AJAX Handlers
    public function handle_login() {
        $email = sanitize_email($_POST['email']);
        $password = sanitize_text_field($_POST['password']);
        
        $result = $this->api->login($email, $password);

        if ($result['success']) {
            wp_send_json_success();
        } else {
            wp_send_json_error($result['message']);
        }
    }

    public function handle_disconnect() {
        delete_option('mp_api_token');
        delete_option('mp_user_info');
        wp_send_json_success();
    }

    public function handle_download() {
        $id = intval($_POST['id']);
        $file_path = $this->api->download_product($id);

        if (is_wp_error($file_path)) {
            wp_send_json_error($file_path->get_error_message());
        }

        // Move to public uploads folder to allow download via browser (TEMPORARY - Secure way is to stream via admin-post.php)
        // For simplicity in this demo, we move to a public URL.
        $upload_dir = wp_upload_dir();
        $file_name = basename($file_path);
        $public_path = $upload_dir['path'] . '/' . $file_name;
        $public_url = $upload_dir['url'] . '/' . $file_name;

        rename($file_path, $public_path);

        wp_send_json_success(array('url' => $public_url));
    }
}
