<?php

class Marketplace_API_Client {

    private $api_url;

    public function __construct() {
        $this->api_url = defined('MARKETPLACE_API_URL') ? MARKETPLACE_API_URL : 'https://caletawp.com/api/v1';
    }

    public function refresh_user_info() {
        $token = get_option('mp_api_token');
        if (!$token) return false;

        $args = array(
            'headers' => array(
                'Authorization' => 'Bearer ' . $token,
                'Accept' => 'application/json',
            ),
            'timeout' => 10,
        );

        $response = wp_remote_get($this->api_url . '/user', $args);

        if (is_wp_error($response) || wp_remote_retrieve_response_code($response) !== 200) {
            return false;
        }

        $user_data = json_decode(wp_remote_retrieve_body($response), true);
        if ($user_data) {
            update_option('mp_user_info', $user_data);
            return $user_data;
        }
        return false;
    }

    public function login($email, $password) {
        $response = wp_remote_post($this->api_url . '/login', array(
            'body' => array(
                'email' => $email,
                'password' => $password,
                'site_url' => get_site_url(), // Domain Locking
            ),
            'timeout' => 15,
        ));

        if (is_wp_error($response)) {
            return array('success' => false, 'message' => $response->get_error_message());
        }

        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);
        $code = wp_remote_retrieve_response_code($response);

        if ($code === 200 && isset($data['token'])) {
            update_option('mp_api_token', $data['token']);
            update_option('mp_user_info', $data['user']);
            return array('success' => true, 'data' => $data);
        } else {
            return array('success' => false, 'message' => $data['message'] ?? 'Error desconocido');
        }
    }

    public function get_products($page = 1, $search = '') {
        $token = get_option('mp_api_token');
        if (!$token) return false;

        $args = array(
            'headers' => array(
                'Authorization' => 'Bearer ' . $token,
                'Accept' => 'application/json',
            ),
            'timeout' => 15,
        );

        $url = $this->api_url . '/products?page=' . $page;
        if($search) $url .= '&search=' . urlencode($search);

        $response = wp_remote_get($url, $args);

        if (is_wp_error($response)) {
            return false;
        }

        return json_decode(wp_remote_retrieve_body($response), true);
    }

    public function download_product($id) {
        $token = get_option('mp_api_token');
        if (!$token) return new WP_Error('no_token', 'No hay sesión activa');

        // Paso 1: Obtener URL de descarga (JSON)
        // Pedimos get_url=1 para evitar redirecciones con headers auth que rompen R2
        $url = $this->api_url . '/download/' . $id . '?get_url=1';

        $response = wp_remote_get($url, array(
            'headers' => array(
                'Authorization' => 'Bearer ' . $token,
                'Accept' => 'application/json'
            ),
            'timeout' => 15
        ));

        if (is_wp_error($response)) {
            return $response;
        }

        $body = json_decode(wp_remote_retrieve_body($response), true);
        
        // Si la API devuelve 'url', es una descarga Cloud (R2/S3)
        // Si devuelve binario directo (local), esto fallará el json_decode o no tendrá 'url'
        $download_url = isset($body['url']) ? $body['url'] : false;

        // Requiere Filesystem de WP para guardar archivos
        require_once(ABSPATH . 'wp-admin/includes/file.php');
        WP_Filesystem();
        global $wp_filesystem;

        // Crear carpeta temporal
        $upload_dir = wp_upload_dir();
        $temp_dir = $upload_dir['basedir'] . '/mp_temp/';
        if (!file_exists($temp_dir)) {
            wp_mkdir_p($temp_dir);
        }

        $destination = $temp_dir . 'product-' . $id . '.zip';

        if ($download_url) {
            // Paso 2A: Descarga Cloud (Limpia, sin Auth Headers)
            $download_response = wp_remote_get($download_url, array(
                'timeout' => 300,
                'stream' => true,
                'filename' => $destination
            ));
        } else {
            // Paso 2B: Descarga Directa (Fallback Local o Legacy)
            // Reintentamos la petición original sin 'get_url' esperando el stream
            $url_direct = $this->api_url . '/download/' . $id;
            $download_response = wp_remote_get($url_direct, array(
                'headers' => array('Authorization' => 'Bearer ' . $token),
                'timeout' => 300,
                'stream' => true,
                'filename' => $destination
            ));
        }

        if (is_wp_error($download_response)) {
             return $download_response;
        }
        
        /* Validar que el archivo no sea un error HTML/JSON (A veces streams guardan error text) */
        $content_type = wp_remote_retrieve_header($download_response, 'content-type');
        if (strpos($content_type, 'application/json') !== false || filesize($destination) < 500) {
             // Es probable que sea un error
             $error_content = file_get_contents($destination);
             $error_json = json_decode($error_content, true);
             return new WP_Error('download_fail', $error_json['message'] ?? 'Error en descarga (Archivo corrupto)');
        }

        return $destination; 
    }
}
