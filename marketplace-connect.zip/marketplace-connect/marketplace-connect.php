<?php
/**
 * Plugin Name: CaletaWP Connect
 * Plugin URI:  https://caletawp.com
 
 * Description: Conecta tu sitio WordPress con nuestro Marketplace para instalar y actualizar recursos premium.
 * Version:     1.0.2
 * Author:      CaletaWP
 * Author URI:  https://caletawp.com
 * License:     GPL-2.0+
 * Text Domain: CaletaWP Connect
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}


define( 'MARKETPLACE_CONNECT_VERSION', '1.0.2' );
define( 'MARKETPLACE_CONNECT_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'MARKETPLACE_CONNECT_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
define( 'MARKETPLACE_API_URL', 'https://caletawp.com/api/v1' );

// Safe Include
$class_file = MARKETPLACE_CONNECT_PLUGIN_DIR . 'includes/class-marketplace-connect.php';

if ( file_exists( $class_file ) ) {
    require_once $class_file;
} else {
    // Si falta el archivo, mostramos un aviso en admin en lugar de error fatal
    add_action( 'admin_notices', function() {
        ?>
        <div class="notice notice-error is-dismissible">
            <p><strong>Error Crítico en Marketplace Connect:</strong> No se encuentra el archivo principal en <code>includes/class-marketplace-connect.php</code>. Por favor verifica que hayas subido la carpeta completa.</p>
        </div>
        <?php
    });
    return; // Detener ejecución del plugin
}

// Initialize Plugin
function run_marketplace_connect() {
	$plugin = new Marketplace_Connect();
	$plugin->run();
}
run_marketplace_connect();
